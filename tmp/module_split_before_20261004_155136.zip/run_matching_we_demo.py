"""Press Run Python File in VS Code to try family/minimum-gap matching WE.

Uses the shared GASettings generation default and keeps plots enabled.
The previous algorithm remains the default in run_hybrid_we_cma_demo.py.
"""
import sys
from pathlib import Path

from run_hybrid_we_cma_demo import main


if __name__ == "__main__":
    output_dir = Path(__file__).resolve().parent
    sys.argv.extend((
        "--war-method", "matching",
        "--figure", str(output_dir / "matching_we_cma_2d_convergence.png"),
        "--output", str(output_dir / "matching_we_cma_2d_convergence.json"),
    ))
    main()
