"""Joint WE/CMA pool, transition prediction and budgeted MILP validation.

Restored from the note (pp. 11--14), the runner contract and the conversation.
One Individual is a complete U-by-4 placement. Predicted placements never
become the reported incumbent. No matching/war_survival routine is called.
The Gaussian covariance and top-K probabilities are model estimates, not
certified error probabilities. See JOINT_TOPK_RESTORATION.md for assumptions.
"""
from __future__ import annotations

from dataclasses import dataclass
from statistics import NormalDist
import math
import numpy as np

from ga import Individual


def _reflect_unit(values):
    return 1.0 - np.abs(np.mod(values, 2.0) - 1.0)


def _resource_statistics(y, power_limits, prb_limits, system_prbs, weights):
    """y = [P_u/Pmax_u, N_u/Nmax_u, C, S]; supports leading sample axes."""
    y = np.asarray(y, dtype=float)
    u = len(power_limits)
    p, n = np.maximum(y[..., :u], 0.), np.maximum(y[..., u:2*u], 0.)
    pbar = p @ power_limits / np.sum(power_limits)
    nbar = n @ prb_limits / system_prbs
    z = np.maximum(np.max(p, axis=-1), np.max(n, axis=-1))
    cost = weights[0]*pbar + weights[1]*nbar + weights[2]*z
    violation = (np.maximum(p-1., 0.).sum(axis=-1)
                 + np.maximum(n-1., 0.).sum(axis=-1) + np.maximum(nbar-1., 0.))
    return pbar, nbar, z, cost, violation


def topk_probabilities(items, predictions, key, target, samples, rng,
                       power_limits, prb_limits, system_prbs, weights, epsilon):
    """Sample primitives, derive (V,-C,-S,J), then rank the WHOLE pool.

    Conditional draws across candidates are independent; within a candidate
    its full covariance is retained. Exact candidates have no sampling noise.
    """
    if samples < 1 or not items:
        raise ValueError("Need a nonempty pool and positive rank sample count")
    count = len(items)
    target = min(max(int(target), 0), count)
    v, c, s, j = [np.empty((samples, count)) for _ in range(4)]
    for i, item in enumerate(items):
        prediction = predictions[key(item)]
        mean = prediction["mean"]
        # Draw even for an exact point so a repeated seed preserves the
        # random numbers for every OTHER point after exact replacement.
        noise = rng.standard_normal((samples, len(mean)))
        if item.exact_result is not None:
            draw = np.broadcast_to(mean, noise.shape)
        else:
            cov = prediction["covariance"]
            vals, vecs = np.linalg.eigh((cov + cov.T)*.5)
            factor = vecs * np.sqrt(np.maximum(vals, 0.))
            draw = mean + noise @ factor.T
            draw[:, :-2] = np.maximum(draw[:, :-2], 0.)
            draw[:, -2:] = np.clip(draw[:, -2:], 0., prediction["service_upper"])
        _, _, _, j[:, i], overload = _resource_statistics(
            draw, power_limits, prb_limits, system_prbs, weights)
        v[:, i] = (item.violation if item.exact_result is not None
                   else prediction["geometry_violation"] + overload)
        c[:, i], s[:, i] = draw[:, -2], draw[:, -1]
    feasible = v <= max(epsilon, 1e-12)
    # Last lexsort key has highest priority. Index only breaks exact ties.
    index = np.broadcast_to(np.arange(count), (samples, count))
    order = np.lexsort((index, j, -s, -c, np.where(feasible, 0., v), ~feasible), axis=1)
    ranks = np.empty_like(order)
    np.put_along_axis(ranks, order, np.broadcast_to(np.arange(1, count+1), order.shape), axis=1)
    return np.mean(ranks <= target, axis=0), np.mean(ranks, axis=0), ranks


def choose_milp_indices(items, probabilities, mean_ranks, target, budget,
                        generation, audit_period, rng, provisional_keys=None):
    """Disjoint elite/boundary/audit sets sharing ONE generation budget.

    provisional_keys is a list of deterministic quality keys, used only to
    break ties in the provisional ordering, not as a second fitness.
    """
    unknown = [i for i, item in enumerate(items) if item.exact_result is None]
    groups = {"elite": [], "boundary": [], "audit": []}
    budget = min(max(int(budget), 0), len(unknown))
    if not budget:
        return groups
    order = sorted(range(len(items)), key=lambda i: (
        -probabilities[i], mean_ranks[i],
        () if provisional_keys is None else provisional_keys[i], i))
    top = set(order[:target])
    elite = next((i for i in order if i in top and i in unknown), None)
    if elite is not None:
        groups["elite"].append(elite)
    remaining = [i for i in unknown if i != elite]
    outside = [i for i in remaining if i not in top]
    if (audit_period > 0 and generation % audit_period == 0
            and outside and budget > len(groups["elite"])):
        audit = int(rng.choice(outside))
        groups["audit"].append(audit)
        remaining.remove(audit)
    remaining.sort(key=lambda i: (-probabilities[i]*(1-probabilities[i]),
                                  abs(mean_ranks[i]-target), mean_ranks[i], i))
    slots = budget - len(groups["elite"]) - len(groups["audit"])
    groups["boundary"] = remaining[:slots]
    return groups


@dataclass
class JointCMA:
    mean: np.ndarray
    covariance: np.ndarray
    path_sigma: np.ndarray
    path_c: np.ndarray
    sigma: float = .08
    updates: int = 0

    @classmethod
    def from_genome(cls, genome, lower, span):
        mean = ((genome-lower)/span).ravel().copy()
        d = len(mean)
        return cls(mean, np.eye(d), np.zeros(d), np.zeros(d))

    def sample(self, count, lower, span, num_uavs, rng):
        vals, vecs = np.linalg.eigh(self.covariance)
        factor = vecs*np.sqrt(np.maximum(vals, 1e-12))
        samples = self.mean + self.sigma*(rng.standard_normal((count, len(self.mean))) @ factor.T)
        return [Individual(lower + _reflect_unit(row).reshape(num_uavs, 4)*span,
                           source=f"cma:{self.updates}") for row in samples]

    def update(self, verified, quality_key, lower, span, mu=2):
        # Every entry must be an actual MILP label from this distribution.
        if len(verified) < 2:
            return False
        if any(x.exact_result is None for x in verified):
            raise ValueError("CMA update requires MILP-evaluated samples")
        selected = sorted(verified, key=quality_key)[:min(mu, len(verified))]
        d = len(self.mean)
        weights = np.log(len(selected)+.5) - np.log(np.arange(1, len(selected)+1))
        weights /= weights.sum()
        mueff = 1. / (weights @ weights)
        cc = (4.+mueff/d)/(d+4.+2.*mueff/d)
        cs = (mueff+2.)/(d+mueff+5.)
        c1 = 2./((d+1.3)**2+mueff)
        cmu = min(1.-c1, 2.*(mueff-2.+1./mueff)/((d+2.)**2+mueff))
        damping = 1.+2.*max(0., math.sqrt((mueff-1.)/(d+1.))-1.)+cs
        positions = np.array([((x.evaluated_genome-lower)/span).ravel() for x in selected])
        steps = (positions-self.mean)/self.sigma
        yw = weights @ steps
        vals, vecs = np.linalg.eigh(self.covariance)
        invsqrt = (vecs / np.sqrt(np.maximum(vals, 1e-12))) @ vecs.T
        self.path_sigma = (1.-cs)*self.path_sigma + math.sqrt(cs*(2.-cs)*mueff)*(invsqrt @ yw)
        self.path_c = (1.-cc)*self.path_c + math.sqrt(cc*(2.-cc)*mueff)*yw
        self.mean = weights @ positions
        self.covariance = ((1.-c1-cmu)*self.covariance
                           + c1*np.outer(self.path_c, self.path_c)
                           + cmu*(steps.T*weights) @ steps + 1e-12*np.eye(d))
        self.covariance = (self.covariance+self.covariance.T)*.5
        chi = math.sqrt(d)*(1.-1./(4*d)+1./(21*d*d))
        self.sigma = float(np.clip(self.sigma*math.exp(np.clip(
            cs/damping*(np.linalg.norm(self.path_sigma)/chi-1.), -1., 1.)), .005, .35))
        self.updates += 1
        return True


class JointTopKMixin:
    """Reuse ContextualCSAEA's oracle, weights and SBX, replace its run loop."""

    def __init__(self, *args, milp_budget=4, rank_samples=64, cma_pre_samples=8,
                 audit_period=5, min_residual_samples=20, nominal_confidence=.95, **kwargs):
        super().__init__(*args, **kwargs)
        if (milp_budget < 1 or rank_samples < 1 or cma_pre_samples < 0
                or audit_period < 0 or min_residual_samples < 2
                or not 0. < nominal_confidence < 1.):
            raise ValueError("Invalid joint top-K budget/calibration settings")
        self.joint_milp_budget = int(milp_budget)
        self.rank_samples, self.cma_pre_samples = int(rank_samples), int(cma_pre_samples)
        self.audit_period, self.min_residual_samples = int(audit_period), int(min_residual_samples)
        self.nominal_confidence = nominal_confidence
        self.joint_exact, self.joint_predictions = {}, {}
        self.joint_records, self.joint_topk_history, self.joint_topk_checks = [], [], []
        self.joint_cma_updates = []
        self._frozen_context = None
        self._frozen_archive, self._frozen_records = None, None
        self._pending_records = []
        self._check_role, self._check_cut = None, None

    def _context(self):
        frozen = getattr(self, "_frozen_context", None)
        return frozen.copy() if frozen is not None else super()._context()

    def _joint_key(self, item):
        # Include the raw genotype: two repaired placements can have different
        # bound violations. The underlying MILP evaluator caches the phenotype.
        return tuple(np.round(np.asarray(item.genome), 7).ravel())

    def _joint_record_y(self, record):
        _, prbs, powers = self._exact_uav_loads(record.milp_result)
        return np.r_[powers/self._uav_power_budgets, prbs/self._uav_prb_budgets,
                     len(record.coverage)/len(self.ues), self._service_score(record.coverage)]

    def _joint_exact_y(self, item):
        _, prbs, powers = self._exact_uav_loads(item.exact_result)
        return np.r_[powers/self._uav_power_budgets, prbs/self._uav_prb_budgets,
                     item.served_fraction, item.service_score]

    def _exact_bottleneck_pressure(self, result):
        _, prbs, powers = self._exact_uav_loads(result)
        p, n = float(np.max(powers/self._uav_power_budgets)), float(np.max(prbs/self._uav_prb_budgets))
        return p, n, max(p, n)

    def _resource_fitness(self, power_w, prbs, bottleneck_pressure, idle_redeployment_pressure=0.):
        return -float(self._resource_weights @ np.array([
            power_w/self.power_budget_w, prbs/self.prb_budget, bottleneck_pressure]))

    def _joint_feature(self, anchor, genome):
        return np.r_[((anchor.genome-self.bounds.lower)/self.bounds.span).ravel(),
                     self._joint_record_y(anchor), ((genome-anchor.genome)/self.bounds.span).ravel()]

    def _joint_weights(self, feature, rows):
        if not rows:
            return np.array([], dtype=int), np.array([]), 1., 0.
        d, m = 4*self.num_uavs, 2*self.num_uavs+2
        ls, la = self.settings.transition_state_bandwidth, self.settings.transition_action_bandwidth
        if ls <= 0 or la <= 0:
            raise ValueError("Transition bandwidths must be positive")
        diff = np.array([row["feature"] for row in rows])-feature
        # Normalize blocks as well as physical coordinates: dimensionality
        # alone must not give geometry an arbitrarily larger weight than m.
        distances = ((diff[:, :d]**2).mean(axis=1)/ls**2
                     + (diff[:, d:d+m]**2).mean(axis=1)/ls**2
                     + (diff[:, d+m:]**2).mean(axis=1)/la**2)
        ids = np.argsort(distances, kind="stable")[:max(1, self.settings.transition_neighbors)]
        w = np.exp(-.5*(distances[ids]-distances[ids[0]]))
        w /= w.sum()
        novelty = float(1.-np.exp(-.5*distances[ids[0]]))
        return ids, w, novelty, float(1./(w @ w))

    def _joint_stats(self, y):
        return _resource_statistics(y, self._uav_power_budgets, self._uav_prb_budgets,
                                    self.prb_budget, self._resource_weights)

    def evaluate_surrogate(self, item):
        key = self._joint_key(item)
        if key in self.joint_exact:
            restored = self.joint_exact[key].clone()
            item.__dict__.update(restored.__dict__)
            item.fitness = self._resource_fitness(item.power_est_w, item.prbs_est, item.bottleneck_pressure)
            y = self._joint_exact_y(item)
            self.joint_predictions[key] = {"mean": y, "covariance": np.zeros((len(y), len(y))),
                "geometry_violation": item.violation, "service_upper": y[-2:].copy()}
            return item
        genome = self._repair(item.genome)
        archive = self.archive if self._frozen_archive is None else self._frozen_archive
        if not archive:
            raise RuntimeError("MILP warm-up is required before prediction")
        anchor = item.anchor_record
        if anchor is None:
            anchor = min(archive, key=lambda a: np.sum(((genome-a.genome)/self.bounds.span)**2))
        feature = self._joint_feature(anchor, genome)
        base = self._joint_record_y(anchor)
        rows = self.joint_records if self._frozen_records is None else self._frozen_records
        ids, w, novelty, neff = self._joint_weights(feature, rows)
        raw_mean = base.copy()
        potential, _, _ = self._coverage_gain(genome)
        upper = np.array([len(potential)/len(self.ues), self._service_score(potential)])
        if len(ids):
            raw_mean += w @ np.array([rows[i]["delta"] for i in ids])
        else:
            # Transfer admission fraction only; no provisional UE association.
            raw_mean[-2] = upper[0]*len(anchor.coverage)/max(1, len(anchor.potential_coverage))
            raw_mean[-1] = upper[1]*self._service_score(anchor.coverage)/max(
                self._service_score(anchor.potential_coverage), 1e-12)
        dimension = len(base)
        bias = np.zeros(dimension)
        calibrated = len(rows) >= self.min_residual_samples
        if calibrated:
            errors = np.array([rows[i]["raw_error"] for i in ids])
            bias = w @ errors
            centered = errors-bias
            covariance = ((centered.T*w) @ centered)/max(1.-float(w @ w), 1e-6)
            covariance += .03**2*(1.+novelty**2+1./max(neff, 1.))*np.eye(dimension)
        else:
            covariance = .2**2*(1.+novelty**2)*np.eye(dimension)
        mean = raw_mean+bias
        mean[:-2] = np.maximum(mean[:-2], 0.)
        mean[-2:] = np.clip(mean[-2:], 0., upper)
        terms = self._violation(item.genome, genome, 0., 0.)
        geometry = terms.total
        _, _, z, cost, overload = self._joint_stats(mean)
        u = self.num_uavs
        terms.power = float(np.maximum(mean[:u]-1., 0.).sum())
        terms.prb = float(overload-terms.power)
        item.evaluated_genome, item.anchor_record = genome, anchor
        item.coverage = potential
        item.power_est_w = float(mean[:u] @ self._uav_power_budgets)
        item.prbs_est = float(mean[u:2*u] @ self._uav_prb_budgets)
        item.served_fraction, item.service_score = map(float, mean[-2:])
        item.power_ratio, item.prb_ratio = float(max(mean[:u])), float(max(mean[u:2*u]))
        item.bottleneck_pressure, item.fitness = float(z), -float(cost)
        item.violation, item.violation_terms = terms.total, terms.as_dict()
        item.uncertainty = float(np.sqrt(np.trace(covariance)/dimension))
        item.exact_result = None
        self.joint_predictions[key] = {"mean": mean.copy(), "raw_mean": raw_mean.copy(),
            "covariance": covariance, "feature": feature, "before": base,
            "geometry_violation": geometry, "service_upper": upper,
            "calibrated": calibrated, "residual_samples": len(rows)}
        return item

    def evaluate_exact(self, item):
        key = self._joint_key(item)
        if key in self.joint_exact:
            return self.evaluate_surrogate(item)
        prediction = self.joint_predictions.get(key)
        super().evaluate_exact(item)
        payload = item.exact_result.get("milp", item.exact_result)
        if not payload.get("solver_optimal", False):
            raise RuntimeError("Joint top-K needs a solver_optimal MILP label; no exact label was accepted")
        y = self._joint_exact_y(item)
        # Local quota and global budget terms use exactly the same primitives
        # as sampled ranks (the allocator itself enforces these constraints).
        terms = self._violation(item.genome, item.evaluated_genome, 0., 0.)
        _, _, _, _, overload = self._joint_stats(y)
        terms.power = float(np.maximum(y[:self.num_uavs]-1., 0.).sum())
        terms.prb = float(overload-terms.power)
        item.violation, item.violation_terms = terms.total, terms.as_dict()
        self.archive[-1].violation = item.violation
        if prediction is not None and "feature" in prediction:
            residual = y-prediction["mean"]
            record = {"feature": prediction["feature"].copy(), "before": prediction["before"].copy(),
                "after": y.copy(), "delta": y-prediction["before"],
                "raw_error": y-prediction["raw_mean"], "error": residual,
                "source": item.source, "generation": self.current_generation, "key": key}
            self._pending_records.append(record)
            exact_j = float(self._joint_stats(y)[3])
            pred_j = float(self._joint_stats(prediction["mean"])[3])
            grad = self._resource_j_gradient(prediction["mean"])
            std = math.sqrt(max(0., float(grad @ prediction["covariance"] @ grad)))
            half = NormalDist().inv_cdf((1.+self.nominal_confidence)/2.)*std
            covered = (abs(exact_j-pred_j) <= half) if prediction["calibrated"] else None
            rescued = (self._joint_quality(item) < self._check_cut
                       if self._check_role == "audit" and self._check_cut is not None else None)
            self.joint_topk_checks.append({"generation": self.current_generation,
                "source": item.source, "role": self._check_role,
                "predicted_j": pred_j, "exact_j": exact_j, "error_j": exact_j-pred_j,
                "interval_lower": pred_j-half, "interval_upper": pred_j+half,
                "interval_covered": covered, "calibrated": prediction["calibrated"],
                "residual_samples": prediction["residual_samples"],
                "audited_false_drop": rescued, "outside_topk_rescue": rescued,
                "error_primitives": residual.tolist()})
        self.joint_exact[key] = item.clone()
        self.evaluate_surrogate(item)  # deterministic exact replacement
        return item

    def _resource_j_gradient(self, y):
        # Delta-method diagnostic for max-load J; not a simultaneous or
        # finite-sample coverage guarantee, particularly near tied maxima.
        u = self.num_uavs
        grad = np.zeros(len(y))
        grad[:u] = self._resource_weights[0]*self._uav_power_budgets/self.power_budget_w
        grad[u:2*u] = self._resource_weights[1]*self._uav_prb_budgets/self.prb_budget
        maxima = np.flatnonzero(np.isclose(y[:2*u], np.max(y[:2*u]), rtol=0., atol=1e-12))
        grad[maxima] += self._resource_weights[2]/len(maxima)
        return grad

    def _joint_freeze(self):
        self._frozen_context = super()._context().copy()
        self._frozen_archive = tuple(self.archive)
        self._frozen_records = tuple(self.joint_records)
        self.joint_predictions.clear()

    def _joint_commit(self):
        self.joint_records.extend(self._pending_records)
        self._pending_records.clear()
        window = max(self.min_residual_samples, 10*self.settings.transition_neighbors)
        self.joint_records = self.joint_records[-window:]
        self._frozen_context = self._frozen_archive = self._frozen_records = None

    def _joint_quality(self, item, epsilon=None):
        eps = self.current_eps if epsilon is None else epsilon
        feasible = item.violation <= max(eps, 1e-12)
        cost = -self._resource_fitness(item.power_est_w, item.prbs_est, item.bottleneck_pressure)
        return (not feasible, 0. if feasible else item.violation,
                -item.served_fraction, -item.service_score, cost)

    def _joint_snapshot(self, best, generation):
        return {"generation": generation, "fitness": -self._joint_quality(best)[-1],
            "violation": best.violation, "served_ues": len(best.coverage),
            "served_fraction": best.served_fraction, "service_score": best.service_score,
            "power_w": best.power_est_w, "prbs": best.prbs_est,
            "power_ratio": best.power_ratio, "prb_ratio": best.prb_ratio,
            "bottleneck_pressure": best.bottleneck_pressure,
            "idle_redeployment_pressure": best.idle_redeployment_pressure,
            "exact_evaluations": len(self.archive),
            "unique_milp_solves": int(getattr(self.milp_evaluator, "unique_solves", len(self.archive))),
            "genome": best.evaluated_genome.tolist(), "epsilon": self.current_eps,
            "resource_weights": self._resource_weights.tolist()}

    def run(self):
        lower, span = np.asarray(self.bounds.lower), self.bounds.span
        initial = self.settings.population_size
        cap = self.settings.population_capacity or 2*initial
        pop = [Individual(self._repair(g), source="initial") for g in self.initial_genomes[:initial]]
        while len(pop) < initial:
            genome = lower+self.rng.random((self.num_uavs, 4))*span
            genome[:, :2] = lower[:2]+.5*span[:2]
            pop.append(Individual(genome, source="initial"))
        for item in pop[:min(initial, max(1, self.settings.initial_milp_seeds))]:
            self.evaluate_exact(item)
        self.update_contextual_model("warmup", pop[:len(self.joint_exact)])
        self._joint_commit()
        best = min(self.joint_exact.values(), key=lambda x: self._joint_quality(x, 0.)).clone()
        self._joint_freeze()
        for item in pop:
            self.evaluate_surrogate(item)
        eps0 = float(np.quantile([x.violation for x in pop], .8))
        self.current_eps = eps0
        self._joint_commit()
        snapshots = [self._joint_snapshot(best, 0)]
        cma = JointCMA.from_genome(best.evaluated_genome, lower, span)
        cma_origins, pending_cma = {}, {}
        for generation in range(1, self.settings.generations+1):
            self.current_generation = generation
            self.current_eps = eps0*max(0., 1.-generation/max(1., .7*self.settings.generations))**2
            if generation > 1 and (generation-1) % max(1, self.settings.update_period) == 0:
                self.update_contextual_model(f"WE-{generation-1}", pop)
            self._joint_freeze()
            # Reserve reproductive space so reaching the cap never stops all
            # variation. The COMPLETE parent+child pool remains <= cap.
            birth_slots = min(cap-2, max(initial, self.cma_pre_samples+2))
            target = min(self._population_target(generation), cap-birth_slots)
            target = max(2, target)
            for item in pop:
                self.evaluate_surrogate(item)
            if len(pop) > cap-birth_slots:
                pop = sorted(pop, key=self._joint_quality)[:cap-birth_slots]
                if all(self._joint_key(x) != self._joint_key(best) for x in pop):
                    pop[-1] = best.clone()
            available = cap-len(pop)
            cma_count = min(self.cma_pre_samples, max(0, available-2))
            brood_count = min(max(initial, target-len(pop)), available-cma_count)
            brood = self._independent_brood(pop, brood_count)
            cma_children = cma.sample(cma_count, lower, span, self.num_uavs, self.rng)
            for item in cma_children:
                item.anchor_record = best.anchor_record
                cma_origins[self._joint_key(item)] = cma.updates
                self.evaluate_surrogate(item)
            unique = {}
            for item in [*pop, *brood, *cma_children]:
                key = self._joint_key(item)
                if key not in unique or item.exact_result is not None:
                    unique[key] = item
            pool = list(unique.values())
            target = min(target, len(pool))
            rank_seed = int(self.rng.integers(0, 2**32))
            def rank_pool():
                return topk_probabilities(pool, self.joint_predictions, self._joint_key,
                    target, self.rank_samples, np.random.default_rng(rank_seed),
                    self._uav_power_budgets, self._uav_prb_budgets, self.prb_budget,
                    self._resource_weights, self.current_eps)
            pi, mean_ranks, _ = rank_pool()
            quality = [self._joint_quality(x) for x in pool]
            provisional = sorted(range(len(pool)), key=lambda i: (-pi[i], mean_ranks[i], quality[i], i))
            cut = quality[provisional[target-1]]
            groups = choose_milp_indices(pool, pi, mean_ranks, target, self.joint_milp_budget,
                generation, self.audit_period, self.rng, quality)
            before_exact = len(self.joint_exact)
            for role, indices in groups.items():
                for i in indices:
                    self._check_role, self._check_cut = role, cut
                    self.evaluate_exact(pool[i])
                    if self._better_exact_incumbent(pool[i], best):
                        best = pool[i].clone()
                    key = self._joint_key(pool[i])
                    if cma_origins.get(key) == cma.updates:
                        pending_cma[key] = pool[i].clone()
            self._check_role = self._check_cut = None
            pi, mean_ranks, _ = rank_pool()
            order = sorted(range(len(pool)), key=lambda i: (
                -pi[i], mean_ranks[i], self._joint_quality(pool[i]), i))
            # The strict incumbent is protected even while population epsilon
            # permits exploratory configurations with a nonzero violation.
            elite_count = min(target, max(1, math.ceil(self.settings.elite_fraction*target)))
            elites = sorted((x for x in pool if x.exact_result is not None),
                            key=lambda x: self._joint_quality(x, 0.))
            selected = {self._joint_key(best): best.clone()}
            for item in elites:
                if len(selected) >= elite_count:
                    break
                selected.setdefault(self._joint_key(item), item)
            for i in order:
                if len(selected) >= target:
                    break
                selected.setdefault(self._joint_key(pool[i]), pool[i])
            pop = list(selected.values())
            if len(pending_cma) >= 2:
                cma.update(list(pending_cma.values()), self._joint_quality, lower, span)
                self.joint_cma_updates.append({"generation": generation,
                    "update": cma.updates, "verified_samples": len(pending_cma),
                    "sigma": cma.sigma, "mean": cma.mean.tolist(),
                    "path_sigma": cma.path_sigma.tolist(), "path_c": cma.path_c.tolist(),
                    "covariance": cma.covariance.tolist()})
                pending_cma.clear()
            active_keys = {self._joint_key(x) for x in pop}
            cma_origins = {k: v for k, v in cma_origins.items() if k in active_keys and v == cma.updates}
            self._joint_commit()
            row = {"generation": generation, "population": len(pop), "population_target": target,
                "pool_size": len(pool), "offspring": len(brood)+len(cma_children),
                "archive_size": len(self.archive), "epsilon": self.current_eps,
                "milp_validations": len(self.joint_exact)-before_exact,
                "elite_checks": len(groups["elite"]), "boundary_checks": len(groups["boundary"]),
                "audit_checks": len(groups["audit"]), "residual_samples": len(self.joint_records),
                "cma_sigma": cma.sigma, "mean_topk_probability": float(np.mean(pi)),
                "best_surrogate_fitness": max(x.fitness for x in pop)}
            self.history.append(row.copy())
            self.joint_topk_history.append(row)
            snapshots.append(self._joint_snapshot(best, generation))
            if generation == 1 or generation % 10 == 0 or generation == self.settings.generations:
                print(f"Joint WE {generation}/{self.settings.generations}: served {len(best.coverage)}/{len(self.ues)}, "
                      f"V={best.violation:.4g}, PRB {best.prbs_est:.0f}/{self.prb_budget:.0f}, "
                      f"P {best.power_est_w:.3f} W; MILP {len(self.archive)}, pool {len(pool)}", flush=True)
        self.current_eps = 0.
        best_genome = best.evaluated_genome.copy()
        # Runner contract indexes the final result by its physical placement.
        self.joint_exact[tuple(np.round(best_genome, 7).ravel())] = best.clone()
        return {"best_genome": best_genome, "best_milp_result": best.exact_result,
            "best_violation": best.violation, "best_violation_terms": best.violation_terms.copy(),
            "archive_size": len(self.archive), "transition_count": len(self.transitions),
            "history": self.history, "exact_incumbent_history": snapshots,
            "trajectory": snapshots, "weight_learning_history": self.weight_learning_history,
            "war_method": "joint-topk", "war_history": [], "exact_trace": self.exact_trace,
            "joint_topk_history": self.joint_topk_history, "joint_topk_checks": self.joint_topk_checks,
            "joint_cma_updates": self.joint_cma_updates}
