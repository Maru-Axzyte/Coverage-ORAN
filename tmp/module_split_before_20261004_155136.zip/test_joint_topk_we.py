"""Small fake-oracle tests. No real UAV MILP simulation is run."""
import contextlib
import io
import json
import tempfile
import unittest
import sys
from pathlib import Path
from unittest.mock import patch

import matplotlib
matplotlib.use("Agg")
import numpy as np

import env
from ga import Bounds, GASettings, Individual
from joint_topk_we import (JointTopKMixin, JointCMA, _resource_statistics,
                           topk_probabilities, choose_milp_indices)
from joint_topk_plots import rolling_quality, draw_surrogate_screening_quality
from run_hybrid_we_cma_demo import ContextualCSAEA, draw_we_service_resource_figure
import run_hybrid_we_cma_demo as runner


class FakeOracle:
    """Deterministic full-schema allocator; deliberately not a radio model."""
    def __init__(self):
        self.unique_solves = 0
        self.solve_seconds = 0.
        self.cache = {}

    def __call__(self, genome):
        key = tuple(np.round(genome, 7).ravel())
        if key in self.cache:
            return self.cache[key]
        self.unique_solves += 1
        # Continuously changing resources and discrete admission.
        count = 1 + int(genome[0, 0] > 499.)
        modes = [{"u": k % len(genome), "uav_id": k % len(genome), "ue_id": k, "num_prbs": 2,
                  "power_w": .2 + .00005*float(genome[k % len(genome), 0])}
                 for k in range(count)]
        powers = [sum(m["power_w"] for m in modes if m["u"] == u) for u in range(len(genome))]
        self.cache[key] = {"total_power_w": sum(powers), "total_num_prbs": 2*count,
            "served_ue_ids": list(range(count)), "evaluated_genome": genome.tolist(),
            "milp": {"uav_mode_choices": modes, "power_by_uav_w": powers,
                     "solver_optimal": True}}
        return self.cache[key]


class SmallJoint(JointTopKMixin, ContextualCSAEA):
    pass


def make_small(**settings):
    values = dict(population_size=4, population_capacity=12, generations=3,
                  initial_milp_seeds=2, children_per_pair=4, sbx_uav_blocks=True,
                  include_separation_constraint=False, random_seed=7, update_period=10)
    values.update(settings)
    return SmallJoint(num_uavs=2,
        ues=[env.UE(0, 500., 500., 5.), env.UE(1, 520., 520., 10.)],
        bounds=Bounds((0., 0., 250., 30.), (1000., 1000., 300., 60.)),
        power_budget_w=4., prb_budget=54., milp_evaluator=FakeOracle(),
        uav_power_budgets_w=[2., 2.], uav_prb_budgets=[27., 27.],
        settings=GASettings(**values), weight_method="fixed",
        milp_budget=3, rank_samples=16, cma_pre_samples=2,
        audit_period=1, min_residual_samples=2)


class JointTests(unittest.TestCase):
    def test_primitive_consistency(self):
        p, n, z, j, v = _resource_statistics(np.array([.5, 1.2, .2, .4, .8, .7]),
            np.array([2., 2.]), np.array([27., 27.]), 54., np.ones(3)/3.)
        self.assertAlmostEqual(p, .85)
        self.assertAlmostEqual(n, .3)
        self.assertAlmostEqual(z, 1.2)
        self.assertAlmostEqual(j, (.85+.3+1.2)/3.)
        self.assertAlmostEqual(v, .2)

    def test_exact_topk_is_deterministic_and_service_first(self):
        items = [Individual(np.array([[float(i), 0., 250., 30.]]),
                    exact_result={}, violation=0.) for i in range(3)]
        predictions = {i: {"mean": np.array([p, p, c, c]), "covariance": np.eye(4),
                        "service_upper": np.ones(2), "geometry_violation": 0.}
                       for i, (p, c) in enumerate([(.9, .8), (.1, .6), (.5, .7)])}
        pi, ranks, _ = topk_probabilities(items, predictions, lambda x: int(x.genome[0, 0]),
            1, 32, np.random.default_rng(1), np.array([2.]), np.array([10.]),
            10., np.ones(3)/3., 0.)
        np.testing.assert_array_equal(pi, [1., 0., 0.])
        np.testing.assert_array_equal(ranks, [1., 3., 2.])

    def test_acquisition_is_disjoint_and_audits_outside(self):
        items = [Individual(np.zeros((1, 4))) for _ in range(8)]
        p = np.array([1., .95, .8, .55, .4, .2, .1, 0.])
        groups = choose_milp_indices(items, p, np.arange(1., 9.), 3, 4, 5, 5,
                                     np.random.default_rng(7))
        flat = sum(groups.values(), [])
        self.assertEqual(len(flat), 4)
        self.assertEqual(len(set(flat)), 4)
        self.assertEqual(groups["elite"], [0])
        self.assertGreaterEqual(groups["audit"][0], 3)
        self.assertIn(3, groups["boundary"])

    def test_batch_freeze_and_exact_replacement(self):
        model = make_small()
        seed = Individual(np.array([[500., 500., 275., 45.], [500., 500., 280., 45.]]))
        model.evaluate_exact(seed)
        model._joint_freeze()
        child = Individual(seed.genome + np.array([10., 0., 0., 0.]), anchor_record=seed.anchor_record)
        other = Individual(seed.genome + np.array([20., 0., 0., 0.]), anchor_record=seed.anchor_record)
        model.evaluate_surrogate(child)
        model.evaluate_surrogate(other)
        before = model.joint_predictions[model._joint_key(other)]["mean"].copy()
        model.evaluate_exact(child)
        self.assertEqual(len(model._frozen_records), 0)
        self.assertEqual(len(model._pending_records), 1)
        model.evaluate_surrogate(other)
        np.testing.assert_array_equal(before, model.joint_predictions[model._joint_key(other)]["mean"])
        pred = model.joint_predictions[model._joint_key(child)]
        np.testing.assert_array_equal(pred["covariance"], 0.)
        n = model.milp_evaluator.unique_solves
        model.evaluate_exact(child.clone())
        self.assertEqual(model.milp_evaluator.unique_solves, n)
        model._joint_commit()
        self.assertEqual(len(model.joint_records), 1)

    def test_small_run_never_calls_old_survival(self):
        model = make_small()
        with patch.object(ContextualCSAEA, "run", side_effect=AssertionError("old run")), \
             patch.object(ContextualCSAEA, "_matching_survival", side_effect=AssertionError("matching")), \
             patch.object(ContextualCSAEA, "_layered_war_survival", side_effect=AssertionError("layered")), \
             contextlib.redirect_stdout(io.StringIO()):
            result = model.run()
        self.assertEqual(len(result["exact_incumbent_history"]), 4)
        self.assertLessEqual(model.milp_evaluator.unique_solves, 2+3*3)
        self.assertTrue(all(r["pool_size"] <= 12 for r in model.history))
        self.assertTrue(all(r["milp_validations"] <= 3 for r in model.history))
        self.assertEqual(result["war_history"], [])
        self.assertTrue(result["best_milp_result"]["milp"]["solver_optimal"])
        self.assertIn(tuple(np.round(result["best_genome"], 7).ravel()), model.joint_exact)
        served = [r["served_ues"] for r in result["exact_incumbent_history"]]
        self.assertEqual(served, sorted(served))
        json.dumps(result, default=lambda x: x.tolist() if isinstance(x, np.ndarray) else x)
        with tempfile.TemporaryDirectory(dir=Path(__file__).resolve().parent / "tmp") as directory:
            output = Path(directory)
            draw_we_service_resource_figure(result["exact_incumbent_history"], output/"service.png")
            draw_surrogate_screening_quality(checks=result["joint_topk_checks"],
                generations=[0, 1, 2, 3], output=output/"quality.png")
            self.assertGreater((output/"service.png").stat().st_size, 1000)
            self.assertGreater((output/"quality.png").stat().st_size, 1000)

    def test_cma_requires_exact_and_covariance_stays_positive(self):
        lower, span = np.array([0., 0., 250., 30.]), np.array([1000., 1000., 50., 30.])
        cma = JointCMA.from_genome(np.array([[500., 500., 275., 45.]]), lower, span)
        items = cma.sample(4, lower, span, 1, np.random.default_rng(1))
        with self.assertRaises(ValueError):
            cma.update(items, lambda x: x.violation, lower, span)
        for i, item in enumerate(items):
            item.exact_result, item.evaluated_genome, item.violation = {}, item.genome.copy(), float(i)
        cma.update(items, lambda x: x.violation, lower, span)
        self.assertEqual(cma.updates, 1)
        self.assertTrue(np.all(np.linalg.eigvalsh(cma.covariance) > 0.))
        self.assertTrue(np.all((cma.mean >= 0.) & (cma.mean <= 1.)))

    def test_missing_audit_evidence_is_not_zero(self):
        result = rolling_quality([], [0, 1])
        self.assertTrue(np.isnan(result[-1]["rescue"]))
        self.assertTrue(np.isnan(result[-1]["coverage"]))

    def test_real_runner_contract_with_fake_oracle(self):
        oracle = FakeOracle()
        with tempfile.TemporaryDirectory(dir=Path(__file__).resolve().parent / "tmp") as directory:
            output = Path(directory)
            argv = ["run_note_we_demo.py", "--joint-topk", "--weight-method", "fixed",
                    "--population", "4", "--population-capacity", "12", "--generations", "2",
                    "--rank-samples", "8", "--cma-population", "2", "--no-show", "--no-open",
                    "--figure", str(output/"fake_test.png"), "--output", str(output/"fake_test.json")]
            with patch.object(sys, "argv", argv), \
                 patch.object(runner, "make_exact_evaluator", return_value=(oracle, oracle.cache)), \
                 patch.object(runner.UAVMILP, "solve", side_effect=AssertionError("No real MILP in test")), \
                 contextlib.redirect_stdout(io.StringIO()):
                runner.main()
            data = json.loads((output/"fake_test.json").read_text(encoding="utf-8"))
            self.assertTrue(data["assumptions"]["joint_topk_enabled"])
            self.assertEqual(data["assumptions"]["generations"], 2)
            for suffix in ["", "_all_steps", "_we_service_resources", "_surrogate_screening_quality"]:
                self.assertGreater((output/f"fake_test{suffix}.png").stat().st_size, 1000)


if __name__ == "__main__":
    unittest.main()
