"""Reproducible 2-D evidence for the C-SAEA + WE + exact-CMA workflow.
"""
from __future__ import annotations

import argparse
import json
import math
import os
import time
from pathlib import Path
from typing import Any, Sequence

import matplotlib.pyplot as plt
from matplotlib.patches import Circle
import numpy as np

import config
import env
from ga import ArchiveRecord, Bounds, CSAEA, GASettings, Individual
from milp import UAVMILP
from preference_weights import ContextualPreferencePair, fit_contextual_pairwise_weights
from war_scheduler import war_survival
from contextual_weight_audit import AuditedContextualWeights
from joint_topk_we import JointTopKMixin

WE_DEFAULTS = GASettings()


# One scenario source: config.py. These compatibility aliases are also used
# by the plotting/comparison helpers; do not put numeric overrides here.
AREA_LENGTH_M = float(config.length_m)
AREA_WIDTH_M = float(config.width_m)
NUM_UAVS = config.num_uavs
NUM_UES = config.num_ues
SYSTEM_PRB_BUDGET = config.system_max_prbs
PRB_BUDGETS = (config.uav_max_prb,) * NUM_UAVS
UAV_POWER_BUDGET_W = config.uav_max_power_w
PRB_BANDWIDTH_HZ = config.PhysConstant().Bandwidth_BRP
UE_DEMANDS_MBPS = tuple(config.required_mbs)


def configured_scenario(*, seed=config.seed, ue_distribution="uniform", quick=False):
    """Build physics and environment from config without starting GA or MILP."""
    phys = config.PhysConstant()
    count, users = (3, 15) if quick else (config.num_uavs, config.num_ues)
    scenario = env.build_random_scenario(
        phys, num_uavs=count, num_ues=users,
        length_m=config.length_m, width_m=config.width_m,
        grid_size=config.grid_size, seed=seed, ue_distribution=ue_distribution,
        prb_budgets=(config.uav_max_prb,) * count,
        power_budgets_w=(config.uav_max_power_w,) * count,
    )
    return phys, scenario


def demand_cluster_seed(ues: Sequence[env.UE], count: int, phys: config.PhysConstant) -> np.ndarray:
    """A reproducible, demand-weighted spatial seed; it is not a final result."""
    points = np.asarray([[ue.x_m, ue.y_m] for ue in ues], dtype=float)
    weights = np.asarray([ue.require_mbps for ue in ues], dtype=float)
    first = int(np.argmin(np.sum((points - np.average(points, axis=0, weights=weights)) ** 2, axis=1)))
    centers = [points[first]]
    while len(centers) < count:
        current = np.asarray(centers)
        distance_sq = np.min(((points[:, None, :] - current[None, :, :]) ** 2).sum(axis=2), axis=1)
        centers.append(points[int(np.argmax(distance_sq * weights))])
    centers = np.asarray(centers)
    for _ in range(20):
        labels = np.argmin(((points[:, None, :] - centers[None, :, :]) ** 2).sum(axis=2), axis=1)
        updated = np.asarray([
            np.average(points[labels == index], axis=0, weights=weights[labels == index])
            if np.any(labels == index) else centers[index]
            for index in range(count)
        ])
        if np.allclose(updated, centers):
            break
        centers = updated
    return np.column_stack((
        centers,
        np.full(count, max(phys.H_U)),
        np.full(count, max(phys.Theta_U)),
    ))


def make_exact_evaluator(
    uavs: Sequence[env.UAV], ues: Sequence[env.UE], phys: config.PhysConstant,
) -> tuple[Any, dict[tuple[float, ...], dict[str, Any]]]:
    """Create the real fixed-placement MILP oracle with a lossless cache."""
    cache: dict[tuple[float, ...], dict[str, Any]] = {}

    def evaluate(genome: np.ndarray) -> dict[str, Any]:
        genome = np.asarray(genome, dtype=float)
        key = tuple(np.round(genome, decimals=7).ravel())
        if key not in cache:
            started = time.perf_counter()
            placements = [env.solution(index, *map(float, row)) for index, row in enumerate(genome)]
            result = UAVMILP(
                uavs=uavs,
                ues=ues,
                placements=placements,
                phys=phys,
                settings=config.exact_solver_settings(),
                fixed_placement_indices=tuple(range(len(uavs))),
                system_prb_budget=SYSTEM_PRB_BUDGET,
                orthogonal_prb_pool=config.global_orthogonal_prb_pool,
            ).solve()
            cache[key] = {
                "total_power_w": float(result["total_power_w"]),
                "total_num_prbs": int(result["total_num_prbs"]),
                "served_ue_ids": sorted({int(item["ue_id"]) for item in result["uav_mode_choices"]}),
                "milp": result,
                "evaluated_genome": genome.tolist(),
            }
            evaluate.solve_seconds += time.perf_counter() - started
            evaluate.unique_solves += 1
        return cache[key]

    evaluate.unique_solves = 0
    evaluate.solve_seconds = 0.0
    return evaluate, cache


class ContextualCSAEA(CSAEA):
    def __init__(self, *args, war_method="layered", weight_method="legacy", **kwargs):
        super().__init__(*args, **kwargs)
        if war_method not in ("matching", "layered", "matching-multi", "matching-multi-reset"):
            raise ValueError("Unknown WE survival method")
        self.war_method = war_method
        if weight_method not in ("legacy", "fixed", "contextual"):
            raise ValueError("Unknown resource-weight method")
        self.weight_method = weight_method
        self.weight_learner = (AuditedContextualWeights(self._resource_weights)
                               if weight_method == "contextual" else None)
        self.war_history = []
        self._brood_families = []
        self.exact_trace = []
        # A neutral prior, not an allegedly learned matrix. CVXPY updates it
        # from exact MILP pairs every update_period generations.
        self.vartheta_prior = np.zeros((3, 5 if self.weight_learner else 4), dtype=float)
        self.vartheta_prior[:, 0] = self._resource_weights
        self.vartheta = self.vartheta_prior.copy()
        self.preference_pairs: list[ContextualPreferencePair] = []
        self.weight_learning_history: list[dict[str, Any]] = []
        self._last_archive_for_learning = 0

    def evaluate_exact(self, item):
        context_before = self._context().copy() if self.weight_learner else None
        super().evaluate_exact(item)
        if self.weight_learner:
            record = self.archive[-1]
            self.weight_learner.observe(
                tuple(np.asarray(record.genome).ravel()), self._resource_vector(record),
                len(record.coverage), self._service_score(record.coverage), record.violation,
                context_before,
            )
        # Actual cache misses, not archive length, measure expensive MILP work.
        self.exact_trace.append({
            "unique_solves": int(getattr(self.milp_evaluator, "unique_solves", len(self.archive))),
            "served_ues": len(item.coverage), "service_score": float(item.service_score),
            "violation": float(item.violation), "power_w": float(item.power_est_w),
            "prbs": float(item.prbs_est), "generation": int(self.current_generation),
            "bottleneck_pressure": float(item.bottleneck_pressure),
            "idle_redeployment_pressure": float(item.idle_redeployment_pressure),
        })

    def _matching_survival(self, pool, target, incumbent, generation, *, families=(), budget=0):
        survivors, report = war_survival(
            pool, target, incumbent, key=self._individual_key, ordered=self._sorted,
            better=self._better, better_exact=self._better_exact_incumbent,
            evaluate_exact=self.evaluate_exact, families=families,
            verification_budget=budget,
            staged=self.war_method.startswith("matching-multi"),
            carry_scores=self.war_method != "matching-multi-reset",
        )
        report["generation"] = generation
        self.war_history.append(report)
        return survivors

    def _context(self) -> np.ndarray:
        """The previous exact incumbent supplies one common comparison context."""
        if not self.archive:
            return np.array([1.0] + [0.0] * (4 if self.weight_learner else 3))
        best_record = max(
            self.archive,
            key=lambda record: (
                record.violation <= 1e-12,
                len(record.coverage), self._service_score(record.coverage),
                -record.prbs, -record.power_w,
            ),
        )
        context = [
            1.0,
            len(best_record.coverage) / len(self.ues),
            np.clip(best_record.power_w / self.power_budget_w, 0.0, 1.0),
            np.clip(best_record.prbs / self.prb_budget, 0.0, 1.0),
        ]
        if self.weight_learner:
            peak_power, _, _ = self._exact_bottleneck_pressure(best_record.milp_result)
            context.append(float(np.clip(peak_power, 0., 1.)))
        return np.asarray(context, dtype=float)

    def _get_contextual_weights(self) -> np.ndarray:
        weights = np.maximum(self.vartheta @ self._context(), 0.0)
        total = float(np.sum(weights))
        return weights / total if total > 1e-12 else self.vartheta_prior[:, 0].copy()

    def _resource_vector(self, record: ArchiveRecord) -> np.ndarray:
        _power_load, _prb_load, bottleneck = self._exact_bottleneck_pressure(record.milp_result)
        return np.array([
            record.power_w / self.power_budget_w,
            record.prbs / self.prb_budget,
            bottleneck,
        ], dtype=float)

    def _refresh_resource_scores(self, items: Sequence[Individual]) -> None:
        """Avoid comparing cached individuals scored under different weights."""
        for item in items:
            item.fitness = self._resource_fitness(
                item.power_est_w, item.prbs_est, item.bottleneck_pressure,
                item.idle_redeployment_pressure,
            )

    def update_contextual_model(self, stage: str, items: Sequence[Individual] = ()) -> None:
        """Fit vartheta from unambiguous exact resource-dominance pairs.

        A label is admitted only when two feasible placements have equal
        service and one uses no more of *every* resource (strictly less of at
        least one).  Non-dominated trade-offs are deliberately left unlabeled:
        MILP observations alone cannot reveal whether the operator values a
        watt or a PRB more highly, and inventing that order would make the
        learned weights circular.
        """
        if self.weight_method != "legacy":
            diagnostics = (self.weight_learner.update(self._context()) if self.weight_learner else {
                "status": "fixed_prior", "new_pairs": 0, "training_pairs": 0,
                "mean_pair_loss": None, "preference_source": "none",
            })
            if self.weight_learner:
                self.vartheta = self.weight_learner.matrix.copy()
            self._resource_weights = self._get_contextual_weights()
            self._refresh_resource_scores(items)
            self.weight_learning_history.append({
                **diagnostics, "stage": stage, "archive_size": len(self.archive),
                "context": self._context().tolist(), "weights": self._resource_weights.tolist(),
                "vartheta": self.vartheta.tolist(), "weight_method": self.weight_method,
            })
            print(f"CVXPY {stage}: {diagnostics['status']}; {self.weight_method}; "
                  f"pairs {diagnostics['training_pairs']}, weights={np.round(self._resource_weights, 3).tolist()}", flush=True)
            return
        context = self._context()
        new_start = self._last_archive_for_learning
        new_pairs: list[tuple[float, ContextualPreferencePair]] = []
        candidate_start = max(0, len(self.archive) - 80)
        for index in range(new_start, len(self.archive)):
            first = self.archive[index]
            if first.violation > 1e-12:
                continue
            first_resource = self._resource_vector(first)
            for other_index in range(candidate_start, index):
                second = self.archive[other_index]
                if (second.violation > 1e-12
                        or len(first.coverage) != len(second.coverage)
                        or abs(self._service_score(first.coverage)
                               - self._service_score(second.coverage)) > 1e-9):
                    continue
                second_resource = self._resource_vector(second)
                separation = float(np.linalg.norm(first_resource - second_resource))
                if separation < 0.002:
                    continue
                tolerance = 1e-9
                first_dominates = (
                    np.all(first_resource <= second_resource + tolerance)
                    and np.any(first_resource < second_resource - tolerance)
                )
                second_dominates = (
                    np.all(second_resource <= first_resource + tolerance)
                    and np.any(second_resource < first_resource - tolerance)
                )
                if not first_dominates and not second_dominates:
                    continue
                better, worse = (
                    (first_resource, second_resource)
                    if first_dominates else (second_resource, first_resource)
                )
                new_pairs.append((separation, ContextualPreferencePair(
                    better=better, worse=worse, context=context.copy(),
                    margin=min(0.02, max(0.003, 0.10 * separation)),
                )))
        self._last_archive_for_learning = len(self.archive)
        # Retain informative recent evidence without an O(|archive|^2) solve.
        new_pairs.sort(key=lambda entry: entry[0], reverse=True)
        self.preference_pairs.extend(pair for _distance, pair in new_pairs[:64])
        self.preference_pairs = self.preference_pairs[-256:]

        status = "insufficient_exact_pairs"
        mean_loss: float | None = None
        if len(self.preference_pairs) >= 3 and new_pairs:
            try:
                fit = fit_contextual_pairwise_weights(
                    self.preference_pairs, prior=self.vartheta_prior,
                    previous=self.vartheta,
                )
                self.vartheta = fit.vartheta
                status, mean_loss = fit.status, fit.mean_pair_loss
            except Exception as error:
                # Keep the last valid model, but make a failed CVXPY solve visible.
                status = f"fit_failed: {type(error).__name__}: {error}"

        self._resource_weights = self._get_contextual_weights()
        self._refresh_resource_scores(items)
        self.weight_learning_history.append({
            "stage": stage,
            "archive_size": len(self.archive),
            "new_pairs": len(new_pairs[:64]),
            "training_pairs": len(self.preference_pairs),
            "status": status,
            "preference_source": "exact_equal_service_pareto_dominance",
            "mean_pair_loss": mean_loss,
            "context": context.tolist(),
            "weights": self._resource_weights.tolist(),
            "vartheta": self.vartheta.tolist(),
        })
        print(
            f"CVXPY {stage}: {status}; pairs {len(self.preference_pairs)}, "
            f"(beta, mu, eta)={np.round(self._resource_weights, 3).tolist()}",
            flush=True,
        )

    def _population_target(self, generation: int) -> int:
        """Expansion -> war -> consolidation schedule from the WE note."""
        initial = self.settings.population_size
        capacity = self.settings.population_capacity or initial
        progress = generation / max(self.settings.generations, 1)
        if progress <= 0.40:
            fraction = progress / 0.40
            target = initial + fraction * (capacity - initial)
        elif progress <= 0.75:
            fraction = (progress - 0.40) / 0.35
            target = capacity - fraction * (capacity - max(initial, capacity // 2))
        else:
            fraction = (progress - 0.75) / 0.25
            middle = max(initial, capacity // 2)
            target = middle - fraction * (middle - max(initial, capacity // 5))
        return int(np.clip(round(target), initial, capacity))

    @staticmethod
    def _individual_key(item: Individual) -> tuple[float, ...]:
        genome = item.evaluated_genome if item.evaluated_genome is not None else item.genome
        return tuple(np.round(np.asarray(genome, dtype=float), 8).ravel())

    def _layered_war_survival(
        self, pool: Sequence[Individual], target: int,
        incumbent: Individual, generation: int,
    ) -> list[Individual]:
        """Four-layer WE with niche migration and exact-elite repatriation.

        The phase changes elimination pressure only.  The comparator remains
        ``(V, -C, -S, f_resource)`` at every phase, so exploration cannot
        silently exchange admitted service for a cheaper resource score.
        """
        if target < 2:
            raise ValueError("A WE population target must be at least two")
        ordered = self._sorted(pool)
        progress = generation / max(self.settings.generations, 1)
        if progress <= 0.40:
            elimination = (0.00, 0.08, 0.18, 0.32)
        elif progress <= 0.75:
            elimination = (0.05, 0.25, 0.50, 0.75)
        else:
            elimination = (0.10, 0.40, 0.70, 0.90)

        protected: list[Individual] = [incumbent.clone()]  # repatriation
        elite_n = max(1, math.ceil(self.settings.elite_fraction * target))
        protected.extend(item.clone() for item in ordered[:elite_n])
        # One representative from each geometric niche migrates into the
        # common survivor pool, even when its original layer is under attack.
        protected.extend(item.clone() for item in self._representatives(ordered))

        candidates: list[Individual] = []
        for layer, rate in zip(np.array_split(np.asarray(ordered, dtype=object), 4), elimination):
            layer_items = list(layer)
            keep = min(len(layer_items), max(1, math.ceil((1.0 - rate) * len(layer_items))))
            candidates.extend(self._roulette(layer_items, keep))

        unique: dict[tuple[float, ...], Individual] = {}
        for item in [*protected, *candidates, *ordered]:
            unique.setdefault(self._individual_key(item), item.clone())
        protected_keys = {self._individual_key(item) for item in protected}
        survivors = [item for key, item in unique.items() if key in protected_keys][:target]
        remaining = [item for key, item in unique.items() if key not in protected_keys]
        survivors.extend(self._roulette(remaining, target - len(survivors)))
        while len(survivors) < target:
            new_item = self._mutate(ordered[len(survivors) % len(ordered)])
            self.evaluate_surrogate(new_item)
            survivors.append(new_item)
        return survivors[:target]

    def _independent_brood(
        self, parents: Sequence[Individual], budget: int,
    ) -> list[Individual]:
        """Create independent siblings from a distinct pair of configurations.

        Parent quality already affects tournament selection.  Letting strong
        pairs also produce more children would apply selection pressure twice
        and can collapse diversity before the layered war has evaluated it.
        """
        if budget <= 0:
            return []
        children: list[Individual] = []
        self._brood_families = []
        while len(children) < budget:
            first = self._tournament(parents)
            alternatives = [p for p in parents
                            if self._individual_key(p) != self._individual_key(first)]
            if not alternatives:
                # A collapsed pool cannot supply a distinct physical parent.
                # Mutation can still restore diversity; do not loop forever.
                alternatives = [p for p in parents if p is not first] or [first]
            second = self._tournament(alternatives)
            family = [self._individual_key(first), self._individual_key(second)]
            family_budget = min(self.settings.children_per_pair, budget - len(children))
            produced = 0
            while produced < family_budget:
                # Always the ORIGINAL two parents, never the previous sibling.
                one, two = self._sbx(first, second)
                for child in (one, two):
                    child = self._mutate(child)
                    self.evaluate_surrogate(child)
                    children.append(child)
                    family.append(self._individual_key(child))
                    produced += 1
                    if produced >= family_budget:
                        break
            self._brood_families.append(family)
        return children

    def run(self) -> dict[str, Any]:
        """C-SAEA compass pre-screening + epsilon-Deb + germline integration."""
        lo, hi = np.asarray(self.bounds.lower), np.asarray(self.bounds.upper)
        # Common physical departure point: x/y are identical for every UAV
        # and every initial individual.  Only h/theta are random initially;
        # subsequent mutation/WE/CMA must discover useful horizontal motion.
        common_xy = 0.5 * (lo[:2] + hi[:2])
        pop = []
        for _ in range(self.settings.population_size):
            genome = self.rng.uniform(lo, hi, (self.num_uavs, 4))
            genome[:, :2] = common_xy
            pop.append(Individual(genome, source="common-xy-random-h-theta"))
        for index, genome in enumerate(self.initial_genomes[:len(pop)]):
            pop[index] = Individual(genome)
        for item in pop[:min(self.settings.initial_milp_seeds, len(pop))]:
            self.evaluate_exact(item)
        for item in pop:
            if item.exact_result is None:
                self.evaluate_surrogate(item)
        self.update_contextual_model("WE-0", pop)
        exact_seeds = [x for x in pop if x.exact_result is not None]
        best = exact_seeds[0].clone()
        for seed in exact_seeds[1:]:
            if self._better_exact_incumbent(seed, best):
                best = seed.clone()
        exact_incumbent_history: list[dict[str, Any]] = []

        # Epsilon is calibrated on this population's violation scale.  A
        # fixed 1.0 changes meaning when the number of UAVs/constraints does.
        eps_0 = max(1e-9, float(np.quantile([x.violation for x in pop], 0.80)))
        self.current_eps = eps_0
        T_c = int(0.7 * self.settings.generations)     # Convergence generation
        cp = 5.0                                       # Decay exponent

        def record_exact_incumbent(generation: int) -> None:
            exact_incumbent_history.append({
                "generation": generation,
                "fitness": float(self._resource_fitness(
                    best.power_est_w, best.prbs_est, best.bottleneck_pressure,
                    best.idle_redeployment_pressure,
                )),
                "violation": float(best.violation),
                "served_ues": int(len(best.coverage)),
                "served_fraction": float(best.served_fraction),
                "service_score": float(best.service_score),
                "power_w": float(best.power_est_w),
                "prbs": float(best.prbs_est),
                "power_ratio": float(best.power_ratio),
                "prb_ratio": float(best.prb_ratio),
                "bottleneck_pressure": float(best.bottleneck_pressure),
                "idle_redeployment_pressure": float(best.idle_redeployment_pressure),
                "exact_evaluations": int(len(self.archive)),
                "unique_milp_solves": int(getattr(self.milp_evaluator, "unique_solves", len(self.archive))),
                "genome": best.evaluated_genome.tolist(),
                "epsilon": float(self.current_eps),
                "resource_weights": self._resource_weights.tolist(),
            })

        record_exact_incumbent(0)
        initial_best = self._sorted(pop)[0]
        trajectory = [
            (initial_best.evaluated_genome if initial_best.evaluated_genome is not None
             else self._repair(initial_best.genome)).copy()
        ]

        for generation in range(1, self.settings.generations + 1):
            self.current_generation = generation
            # One shared context/weight vector per generation. Previously
            # each exact evaluation could silently alter weights mid-ranking.
            self._resource_weights = self._get_contextual_weights()
            self._refresh_resource_scores([*pop, best])
            # --- Epsilon decay (Eq. 17): explore early, strict late ---
            if generation < T_c:
                self.current_eps = eps_0 * (1.0 - generation / T_c) ** cp
            else:
                self.current_eps = 0.0

            # 1. Reserve room for independent siblings.  The active cohort
            # expands to the ceiling and later contracts under stronger war.
            target_size = (
                self._population_target(generation)
                if self.settings.use_war_elimination else self.settings.population_size
            )
            capacity = self.settings.population_capacity or target_size
            brood_budget = min(max(2, target_size // 4), capacity - 2)
            parent_target = max(2, min(len(pop), target_size - brood_budget))
            matching = self.settings.use_war_elimination and self.war_method.startswith("matching")
            if matching:
                # Reserve only against the HARD cap. Otherwise allow parents
                # and children to compete together above the survivor target.
                parent_target = max(2, min(len(pop), capacity - brood_budget))
            if len(pop) > parent_target:
                pop = (self._matching_survival(pop, parent_target, best, generation)
                       if matching else self._layered_war_survival(pop, parent_target, best, generation))
            brood_budget = min(capacity - len(pop), max(brood_budget, target_size - len(pop)))
            candidate_pool = self._independent_brood(pop, brood_budget)
            if not candidate_pool:
                raise RuntimeError("Population capacity leaves no room for offspring")

            # 2. Transition-surrogate compass pre-screening
            ranked = self._sorted(candidate_pool)

            # 3. Exact MILP evaluation for top candidate
            # Matching reallocates this ONE call to the contested cut. It does
            # not add a MILP call per match or per family.
            for top_item in (ranked[:1] if not matching else []):
                if top_item.exact_result is None:
                    self.evaluate_exact(top_item)
                if self._better_exact_incumbent(top_item, best):
                    best = top_item.clone()

            # 4. All independent siblings enter the same layered war.
            if matching:
                pop = self._matching_survival(
                    [*pop, *candidate_pool], target_size, best, generation,
                    families=self._brood_families, budget=1,
                )
            else:
                pop = (
                    self._layered_war_survival(
                        [*pop, *candidate_pool], target_size, best, generation,
                    )
                    if self.settings.use_war_elimination
                    else self._baseline_survival([*pop, *candidate_pool])
                )

            for item in pop:
                if item.exact_result is not None and self._better_exact_incumbent(item, best):
                    best = item.clone()

            generation_best = self._sorted(pop)[0]
            trajectory.append(
                (generation_best.evaluated_genome if generation_best.evaluated_genome is not None
                 else self._repair(generation_best.genome)).copy()
            )

            # 5. Periodic infill + Germline Integration (Step 2g)
            if generation % self.settings.update_period == 0:
                feasible = [x for x in pop if x.violation <= self.current_eps]
                if not feasible:
                    feasible = pop
                for item in self._representatives(feasible):
                    if item.exact_result is None:
                        self.evaluate_exact(item)
                    if self._better_exact_incumbent(item, best):
                        best = item.clone()
                for item in self._unserved_target_variants(best):
                    self.evaluate_exact(item)
                    if self._better_exact_incumbent(item, best):
                        best = item.clone()
                    # Step 2g: inject infill directly into mating pool
                    worst_idx = 0
                    for idx in range(1, len(pop)):
                        if self._better(pop[worst_idx], pop[idx]):
                            worst_idx = idx
                    if self._better(item, pop[worst_idx]):
                        pop[worst_idx] = item.clone()

                self.update_contextual_model(f"WE-{generation}", [*pop, best])

            self.history.append({
                "generation": float(generation),
                "best_surrogate_fitness": max(x.fitness for x in pop),
                "archive_size": float(len(self.archive)),
                "epsilon": float(self.current_eps),
                "population": float(len(pop)),
                "population_target": float(target_size),
                "offspring": float(len(candidate_pool)),
            })
            record_exact_incumbent(generation)
            if generation == 1 or generation % 10 == 0 or generation == self.settings.generations:
                print(
                    f"WE {generation}/{self.settings.generations}: "
                    f"served {len(best.coverage)}/{len(self.ues)}, "
                    f"PRB {best.prbs_est:.0f}/{self.prb_budget:.0f}, "
                    f"P {best.power_est_w:.3f} W; "
                    f"exact {len(self.archive)}, transitions {len(self.transitions)}",
                    flush=True,
                )

        # Final: ensure best is strictly feasible (eps=0)
        self.current_eps = 0.0
        return {
            "best_genome": (
                best.evaluated_genome if best.evaluated_genome is not None
                else self._repair(best.genome)
            ).copy(),
            "best_milp_result": best.exact_result,
            "best_violation": best.violation,
            "best_violation_terms": best.violation_terms.copy(),
            "archive_size": len(self.archive),
            "transition_count": len(self.transitions),
            "history": self.history,
            "trajectory": trajectory,
            "exact_incumbent_history": exact_incumbent_history,
            "weight_learning_history": self.weight_learning_history,
            "war_method": self.war_method,
            "war_history": self.war_history,
            "exact_trace": self.exact_trace,
        }

def build_ga(
    *, uavs: Sequence[env.UAV], ues: Sequence[env.UE], phys: config.PhysConstant,
    evaluator: Any, population: int, population_capacity: int,
    generations: int, use_we: bool, seed: int, war_method: str = "layered",
    weight_method: str = "legacy",
    screening_settings: Any = None,
    joint_topk: bool = False, joint_milp_budget: int = 4,
    rank_samples: int = 64, cma_pre_samples: int = 8,
    audit_period: int = 5, min_residual_samples: int = 20,
    nominal_confidence: float = .95,
) -> CSAEA:
    bounds = Bounds(
        (0.0, 0.0, min(phys.H_U), min(phys.Theta_U)),
        (AREA_LENGTH_M, AREA_WIDTH_M, max(phys.H_U), max(phys.Theta_U)),
    )
    ga_class = ContextualCSAEA
    extra = {}
    if joint_topk:

        class JointTopKCSAEA(JointTopKMixin, ContextualCSAEA):
            pass

        ga_class = JointTopKCSAEA
        extra.update(milp_budget=joint_milp_budget,
                     rank_samples=rank_samples,
                     cma_pre_samples=cma_pre_samples,
                     audit_period=audit_period,
                     min_residual_samples=min_residual_samples,
                     nominal_confidence=nominal_confidence)
    if screening_settings is not None:
        if joint_topk:
            raise ValueError("Choose either joint top-K or legacy Student-t screening")
        if not use_we or war_method != "matching":
            raise ValueError("Student-t screening requires WE and --war-method matching")
        # Optional import: old runners do not import or activate the new mode.
        from student_t_we import StudentTScreeningMixin

        class StudentTContextualCSAEA(StudentTScreeningMixin, ContextualCSAEA):
            pass

        ga_class = StudentTContextualCSAEA
        extra["screening_settings"] = screening_settings
    return ga_class(
        **extra,
        war_method=war_method, weight_method=weight_method,
        num_uavs=len(uavs), ues=ues, bounds=bounds,
        power_budget_w=sum(uav.max_power_w for uav in uavs),
        prb_budget=SYSTEM_PRB_BUDGET,
        milp_evaluator=evaluator,
        initial_genomes=None,
        phys=phys,
        uav_power_budgets_w=[uav.max_power_w for uav in uavs],
        uav_prb_budgets=[uav.max_prbs for uav in uavs],
        settings=GASettings(
            population_size=population,
            population_capacity=population_capacity,
            generations=generations,
            initial_milp_seeds=min(WE_DEFAULTS.initial_milp_seeds, population),
            update_period=WE_DEFAULTS.update_period,
            clusters=min(WE_DEFAULTS.clusters, population),
            unserved_infill_variants=WE_DEFAULTS.unserved_infill_variants,
            use_war_elimination=use_we,
            include_separation_constraint=True,
            min_uav_separation_m=config.uav_min_separation_m,
            random_seed=seed,
            sbx_uav_blocks=screening_settings is not None or joint_topk,
            children_per_pair=10 if screening_settings is not None or joint_topk else 2,
        ),
    )


def exact_cma_refinement(
    ga: CSAEA, result: dict[str, Any], *, iterations: int, population: int,
    seed: int,
) -> tuple[Individual, list[dict[str, Any]]]:
    """Joint ``4 * num_uavs`` CMA-ES; only exact MILP ranks its update.

    The transition surrogate pre-screens a larger sample, but the mean,
    evolution paths, covariance and step size are updated exclusively from
    the exact-MILP-ranked subset.  This implements the coupled CMA equations
    in the note rather than running an unrelated four-dimensional search for
    each UAV.
    """
    if population < 4 or population % 2:
        raise ValueError("CMA population must be an even number of at least 4")
    if (ga.settings.population_capacity is not None
            and 1 + 5 * population > ga.settings.population_capacity):
        raise ValueError("CMA prescreening pool exceeds population_capacity")
    rng = np.random.default_rng(seed)
    lower = np.tile(np.asarray(ga.bounds.lower, dtype=float), ga.num_uavs)
    span = np.tile(np.asarray(ga.bounds.span, dtype=float), ga.num_uavs)
    dimension = 4 * ga.num_uavs

    def reflect_unit(values: np.ndarray) -> np.ndarray:
        """Smoothly reflect samples at [0,1] instead of clipping them."""
        folded = np.mod(values, 2.0)
        return np.where(folded <= 1.0, folded, 2.0 - folded)

    def covariance_factors(matrix: np.ndarray) -> tuple[np.ndarray, np.ndarray, float]:
        matrix = 0.5 * (matrix + matrix.T)
        eigenvalues, eigenvectors = np.linalg.eigh(matrix)
        eigenvalues = np.maximum(eigenvalues, 1e-12)
        root = (eigenvectors * np.sqrt(eigenvalues)) @ eigenvectors.T
        inverse_root = (eigenvectors * (1.0 / np.sqrt(eigenvalues))) @ eigenvectors.T
        return root, inverse_root, float(eigenvalues[-1] / eigenvalues[0])

    incumbent = Individual(np.asarray(result["best_genome"], dtype=float).copy())
    archive_size_before = len(ga.archive)
    ga.evaluate_exact(incumbent)
    # The incumbent is already in the archive from the GA phase.  This call
    # reconstructs its exact fitness for CMA but must not be counted as a new
    # MILP validation in the convergence plot.
    del ga.archive[archive_size_before:]

    mean = (incumbent.evaluated_genome.ravel() - lower) / span
    covariance = np.eye(dimension)
    sigma = 0.08
    path_sigma = np.zeros(dimension)
    path_c = np.zeros(dimension)

    mu = population // 2
    raw_weights = np.log(mu + 0.5) - np.log(np.arange(1, mu + 1))
    weights = raw_weights / raw_weights.sum()
    mu_eff = 1.0 / float(np.sum(weights ** 2))
    c_sigma = (mu_eff + 2.0) / (dimension + mu_eff + 5.0)
    d_sigma = 1.0 + 2.0 * max(0.0, math.sqrt((mu_eff - 1.0) / (dimension + 1.0)) - 1.0) + c_sigma
    c_c = (4.0 + mu_eff / dimension) / (dimension + 4.0 + 2.0 * mu_eff / dimension)
    c_1 = 2.0 / ((dimension + 1.3) ** 2 + mu_eff)
    c_mu = min(
        1.0 - c_1,
        2.0 * (mu_eff - 2.0 + 1.0 / mu_eff) / ((dimension + 2.0) ** 2 + mu_eff),
    )
    chi_n = math.sqrt(dimension) * (
        1.0 - 1.0 / (4.0 * dimension) + 1.0 / (21.0 * dimension ** 2)
    )
    trace: list[dict[str, Any]] = []

    for step in range(1, iterations + 1):
        root, inverse_root, condition_number = covariance_factors(covariance)
        old_mean = mean.copy()
        pool: list[Individual] = []
        for _ in range(5 * population):
            y = root @ rng.normal(size=dimension)
            sampled = reflect_unit(old_mean + sigma * y)
            genome = (lower + sampled * span).reshape(ga.num_uavs, 4)
            pool.append(Individual(
                genome, anchor_record=incumbent.anchor_record, source="joint-cma",
            ))
        for item in pool:
            ga.evaluate_surrogate(item)
        candidates = ga._sorted(pool)[:population]
        for item in candidates:
            ga.evaluate_exact(item)
        ranked = ga._sorted(candidates)
        selected = ranked[:mu]

        selected_normalised = np.asarray([
            (item.evaluated_genome.ravel() - lower) / span for item in selected
        ])
        selected_steps = (selected_normalised - old_mean) / max(sigma, 1e-12)
        mean_step = np.sum(weights[:, None] * selected_steps, axis=0)
        mean = reflect_unit(old_mean + sigma * mean_step)

        path_sigma = (
            (1.0 - c_sigma) * path_sigma
            + math.sqrt(c_sigma * (2.0 - c_sigma) * mu_eff)
            * (inverse_root @ mean_step)
        )
        normalised_path = np.linalg.norm(path_sigma) / math.sqrt(
            max(1e-12, 1.0 - (1.0 - c_sigma) ** (2 * step))
        )
        h_sigma = float(
            normalised_path < (1.4 + 2.0 / (dimension + 1.0)) * chi_n
        )
        path_c = (
            (1.0 - c_c) * path_c
            + h_sigma * math.sqrt(c_c * (2.0 - c_c) * mu_eff) * mean_step
        )
        rank_mu = sum(
            weight * np.outer(vector, vector)
            for weight, vector in zip(weights, selected_steps)
        )
        covariance = (
            (1.0 - c_1 - c_mu) * covariance
            + c_1 * (
                np.outer(path_c, path_c)
                + (1.0 - h_sigma) * c_c * (2.0 - c_c) * covariance
            )
            + c_mu * rank_mu
            + 1e-12 * np.eye(dimension)
        )
        covariance = 0.5 * (covariance + covariance.T)
        sigma *= math.exp((c_sigma / d_sigma) * (np.linalg.norm(path_sigma) / chi_n - 1.0))
        sigma = float(np.clip(sigma, 0.005, 0.35))

        improved = ga._better_exact_incumbent(ranked[0], incumbent)
        if improved:
            incumbent = ranked[0].clone()

        if isinstance(ga, ContextualCSAEA):
            ga.update_contextual_model(f"SA-CMA-{step}", [incumbent])

        # Record trace once per full coordinate sweep (all UAVs)
        trace.append({
            "stage": f"SA-CMA-{step}",
            "exact_evaluations": len(ga.archive),
            "fitness": float(ga._resource_fitness(
                incumbent.power_est_w, incumbent.prbs_est,
                incumbent.bottleneck_pressure, incumbent.idle_redeployment_pressure,
            )),
            "violation": float(incumbent.violation),
            "served_ues": int(len(incumbent.coverage)),
            "served_fraction": float(incumbent.served_fraction),
            "service_score": float(incumbent.service_score),
            "power_w": float(incumbent.power_est_w),
            "prbs": float(incumbent.prbs_est),
            "power_ratio": float(incumbent.power_ratio),
            "prb_ratio": float(incumbent.prb_ratio),
            "bottleneck_pressure": float(incumbent.bottleneck_pressure),
            "idle_redeployment_pressure": float(incumbent.idle_redeployment_pressure),
            "sigma": sigma,
            "covariance_condition": condition_number,
            "improved": bool(improved),
            "genome": incumbent.evaluated_genome.tolist(),
            "resource_weights": ga._resource_weights.tolist(),
        })
    return incumbent, trace


def snapshot_metrics(record: dict[str, Any]) -> str:
    return (
        f"served {record['served_ues']}/{NUM_UES}\n"
        f"PRB {record['prbs']:.0f}/{SYSTEM_PRB_BUDGET} | P {record['power_w']:.2f} W"
    )


def draw_snapshot(
    ax: Any, *, title: str, genome: np.ndarray, exact: dict[str, Any],
    ues: Sequence[env.UE], phys: config.PhysConstant,
) -> None:
    milp = exact["milp"]
    served = set(exact["served_ue_ids"])
    assignments = {int(choice["ue_id"]): int(choice["uav_id"]) for choice in milp["uav_mode_choices"]}
    uav_prbs = np.zeros(len(genome), dtype=int)
    uav_power = np.zeros(len(genome), dtype=float)
    uav_ues = np.zeros(len(genome), dtype=int)
    for choice in milp["uav_mode_choices"]:
        index = int(choice["u"])
        uav_prbs[index] += int(choice["num_prbs"])
        uav_power[index] += float(choice["power_w"])
        uav_ues[index] += 1
    palette = plt.cm.tab10(np.arange(len(genome)))
    demand_colors = {5.0: "#4cd137", 10.0: "#fbc531", 15.0: "#e84118"}  # Xanh lá, Vàng, Đỏ

    for ue in ues:
        req = float(ue.require_mbps)
        ue_color = demand_colors.get(req, "#7f8fa6")

        if ue.id in served:
            uav_idx = assignments[ue.id]
            uav_color = palette[uav_idx % len(palette)]
            uav_x, uav_y = genome[uav_idx][:2]

            # Vẽ đường nối mờ từ UAV đến UE để biết UE thuộc UAV nào
            ax.plot([ue.x_m, uav_x], [ue.y_m, uav_y], color=uav_color, alpha=0.3, linewidth=1.2, zorder=2)

            # Vẽ vòng tròn UE, tô màu theo demand, viền theo màu UAV
            ax.scatter(ue.x_m, ue.y_m, s=36 + 3 * req, facecolor=ue_color,
                       edgecolor=uav_color, linewidth=1.5, zorder=5)
        else:
            # Vẽ dấu X cho UE rớt mạng, màu theo demand
            ax.scatter(ue.x_m, ue.y_m, marker="x", s=50 + 3 * req, linewidth=2.0,
                       color=ue_color, zorder=4)
    for index, (x, y, h, theta) in enumerate(genome):
        radius = env.coverage_radius(float(h), float(theta))
        ax.add_patch(Circle((x, y), radius, facecolor=palette[index], edgecolor=palette[index],
                            alpha=.10, linewidth=1.2, zorder=1))
        ax.scatter(x, y, marker="^", s=104, color=palette[index], edgecolor="black",
                   linewidth=.55, zorder=6)
        ax.annotate(
            f"U{index + 1}: {uav_ues[index]} UE\n"
            f"{uav_prbs[index]}/{PRB_BUDGETS[index]} PRB | {uav_power[index]:.2f}/{UAV_POWER_BUDGET_W:.1f} W",
            (x, y),
            xytext=(-6 if x > .72 * AREA_LENGTH_M else 6,
                    -6 if y > .86 * AREA_WIDTH_M else 6),
            textcoords="offset points", fontsize=6.6, weight="bold", zorder=7,
            ha="right" if x > .72 * AREA_LENGTH_M else "left",
            va="top" if y > .86 * AREA_WIDTH_M else "bottom",
            bbox={"boxstyle": "round,pad=.14", "facecolor": "white", "alpha": .72, "edgecolor": "none"},
        )
    ax.set_title(title, fontsize=10, weight="bold")
    ax.text(.02, .03, snapshot_metrics({
        "served_ues": len(served), "prbs": exact["total_num_prbs"], "power_w": exact["total_power_w"],
    }), transform=ax.transAxes, fontsize=8, va="bottom",
        bbox={"boxstyle": "round,pad=.28", "facecolor": "white", "alpha": .86, "edgecolor": "#b0b0b0"})
    ax.set_xlim(0, AREA_LENGTH_M)
    ax.set_ylim(0, AREA_WIDTH_M)
    ax.set_aspect("equal", adjustable="box")
    ax.set_xticks([])
    ax.set_yticks([])
    ax.grid(alpha=.17)


def draw_figure(
    *, ues: Sequence[env.UE], phys: config.PhysConstant, evaluator: Any,
    we_history: list[dict[str, Any]], baseline_history: list[dict[str, Any]] | None,
    cma_history: list[dict[str, Any]], output: Path, show: bool,
    joint_topk: bool = False,
) -> None:
    # Five true milestones: initial, two GA incumbents, and two CMA incumbents.
    # Keep exactly three GA panels.  In a short smoke test some (or all)
    # panels legitimately refer to the same incumbent; removing duplicates
    # here used to cause an IndexError while saving the figure.
    ga_indices = [0, len(we_history) // 2, len(we_history) - 1]
    snapshots = [we_history[index] for index in ga_indices]
    titles = [
        "MILP seed (generation 0)",
        f"C-SAEA + WE (generation {int(we_history[ga_indices[1]]['generation'])})",
        f"C-SAEA + WE (generation {int(we_history[ga_indices[2]]['generation'])})",
    ]
    if not joint_topk:
        snapshots += [cma_history[0], cma_history[-1]]
        titles += ["Exact-CMA local refinement: step 1",
                   f"Final hybrid: Exact-CMA step {len(cma_history)}"]
    figure = plt.figure(figsize=(16, 10))
    grid = figure.add_gridspec(2, 3, height_ratios=(1.0, .86), hspace=.24, wspace=.14)
    map_axes = [figure.add_subplot(grid[0, column]) for column in range(3)]
    if joint_topk:
        chart = figure.add_subplot(grid[1, :])
    else:
        map_axes += [figure.add_subplot(grid[1, 0]), figure.add_subplot(grid[1, 1])]
        chart = figure.add_subplot(grid[1, 2])
    for ax, title, snapshot in zip(map_axes, titles, snapshots):
        genome = np.asarray(snapshot["genome"], dtype=float)
        draw_snapshot(ax, title=title, genome=genome, exact=evaluator(genome), ues=ues, phys=phys)
    for ax in map_axes[len(snapshots):]:
        ax.axis("off")

    curves: list[tuple[str, list[dict[str, Any]], str, str]] = [
        ("Joint WE + CMA" if joint_topk else "C-SAEA + WE",
         we_history, "-", "#187a48"),
    ]
    if not joint_topk:
        curves.append(("Exact-CMA refinement", [we_history[-1], *cma_history],
                       "--", "#6e48aa"))
    if baseline_history is not None:
        curves.insert(0, ("GA baseline (same MILP budget)", baseline_history, "-", "#7b8794"))
    for name, history, style, color in curves:
        values = np.maximum.accumulate([row.get("served_fraction", 0.0) for row in history])
        chart.plot([row["exact_evaluations"] for row in history], values,
                   linestyle=style, linewidth=2.1, marker="o", markersize=3.2,
                   color=color, label=name)
    chart.set_title("MILP-verified service convergence", fontsize=10, weight="bold")
    chart.set_xlabel("Exact MILP validations")
    chart.set_ylabel("Best exact admitted-UE fraction")
    chart.grid(alpha=.25)
    chart.legend(fontsize=7.2, loc="best")
    chart.text(
        .03, -.26,
        "All maps and curve points use env.py LoS/NLoS + orthogonal-PRB SNR and the exact HiGHS MILP.\n"
        "Surrogate values never appear as final evidence.",
        transform=chart.transAxes, fontsize=7.6, va="top",
    )
    figure.suptitle(
        f"{NUM_UAVS} UAV / {NUM_UES} UE: C-SAEA + War Elimination + "
        f"{'joint CMA' if joint_topk else 'Exact-CMA'}\n"
        f"{SYSTEM_PRB_BUDGET} system PRBs, {phys.Bandwidth_BRP / 1e3:g} kHz per PRB, {UAV_POWER_BUDGET_W} W per UAV, UE demand {list(UE_DEMANDS_MBPS)} Mbps",
        weight="bold", y=.985,
    )
    figure.savefig(output, dpi=230, bbox_inches="tight")
    if show:
        plt.show()
    plt.close(figure)


def draw_all_steps_figure(
    *, ues: Sequence[env.UE], phys: config.PhysConstant, evaluator: Any,
    we_history: list[dict[str, Any]], cma_history: list[dict[str, Any]], output: Path,
    snapshot_period: int, joint_topk: bool = False,
) -> None:
    """A readable 2-D panel for every requested WE milestone and CMA step."""
    if snapshot_period <= 0:
        raise ValueError("snapshot_period must be positive")
    all_steps = [
        (f"WE generation {int(item['generation'])}", item)
        for item in we_history
        if int(item["generation"]) % snapshot_period == 0
    ] + [
        (str(item["stage"]), item)
        for item in cma_history
    ]
    columns = 4
    rows = int(np.ceil(len(all_steps) / columns))
    figure, axes = plt.subplots(rows, columns, figsize=(4.3 * columns, 4.0 * rows))
    for ax, (title, item) in zip(np.ravel(axes), all_steps):
        genome = np.asarray(item["genome"], dtype=float)
        draw_snapshot(ax, title=title, genome=genome, exact=evaluator(genome), ues=ues, phys=phys)
    for ax in np.ravel(axes)[len(all_steps):]:
        ax.axis("off")
    figure.suptitle(
        f"MILP-verified incumbent every {snapshot_period} WE generations"
        f"{', with joint CMA' if joint_topk else ', then Exact-CMA'}\n"
        f"{NUM_UAVS} UAV / {NUM_UES} UE, {SYSTEM_PRB_BUDGET} PRBs, {phys.Bandwidth_BRP / 1e3:g} kHz/PRB, {UAV_POWER_BUDGET_W} W/UAV",
        weight="bold", y=.995,
    )
    figure.tight_layout(rect=(0, 0, 1, .96))
    figure.savefig(output, dpi=210, bbox_inches="tight")
    plt.close(figure)


def draw_we_service_resource_figure(
    we_history: Sequence[dict[str, Any]], output: Path,
) -> None:
    """Plot exact service and normalized resource use at every WE generation.

    ``we_history`` contains only incumbent values confirmed by the fixed-
    placement MILP.  The two resource ratios therefore use the same budgets
    as the optimizer, rather than surrogate estimates.
    """
    if not we_history:
        raise ValueError("we_history must contain at least one exact incumbent")

    generations = np.asarray([row["generation"] for row in we_history], dtype=int)
    served = np.asarray([row["served_ues"] for row in we_history], dtype=float)
    mean_power_load = np.asarray([
        row["power_w"] / (NUM_UAVS * UAV_POWER_BUDGET_W)
        for row in we_history
    ], dtype=float)
    mean_prb_load = np.asarray([
        row["prbs"] / SYSTEM_PRB_BUDGET
        for row in we_history
    ], dtype=float)

    figure, served_axis = plt.subplots(figsize=(10.5, 5.8))
    resource_axis = served_axis.twinx()
    service_line, = served_axis.plot(
        generations, served, color="#187a48", linewidth=2.4,
        marker="o", markersize=3.2, label="Served UE (exact MILP)",
    )
    power_line, = resource_axis.plot(
        generations, mean_power_load, color="#c44e52", linewidth=2.0,
        label=r"Mean normalized power $\bar p$",
    )
    prb_line, = resource_axis.plot(
        generations, mean_prb_load, color="#4c72b0", linewidth=2.0,
        label=r"Normalized system PRBs $\bar n$",
    )
    resource_axis.axhline(1.0, color="0.45", linestyle=":", linewidth=1.2,
                          label="Resource limit")

    served_axis.set_xlabel("WE generation")
    served_axis.set_ylabel("Number of served UEs", color="#187a48")
    served_axis.set_ylim(0, max(float(NUM_UES), float(np.max(served))) * 1.05)
    served_axis.tick_params(axis="y", labelcolor="#187a48")
    resource_axis.set_ylabel("Normalized resource load", color="#3b4a66")
    resource_top = max(1.05, 1.05 * float(np.max([mean_power_load, mean_prb_load])))
    resource_axis.set_ylim(0, resource_top)
    served_axis.grid(alpha=.25)
    served_axis.set_title(
        "MILP-verified service and resource use over WE generations",
        weight="bold",
    )
    lines = [service_line, power_line, prb_line]
    served_axis.legend(lines, [line.get_label() for line in lines], loc="best")
    served_axis.text(
        .01, -.20,
        r"$\bar p_t=\sum_u P_u(t)/(U P_u^{\max})$,  "
        r"$\bar n_t=\sum_u N_u(t)/N_{\rm sys}^{\max}$; lower resource load is better.",
        transform=served_axis.transAxes, fontsize=9, va="top",
    )
    figure.tight_layout()
    figure.savefig(output, dpi=180, bbox_inches="tight")
    plt.close(figure)


def show_saved_figures(paths: Sequence[Path]) -> None:
    """Open saved PNGs in Matplotlib windows after all computations finish."""
    for path in paths:
        image = plt.imread(path)
        figure, axis = plt.subplots(figsize=(15, 10))
        axis.imshow(image)
        axis.set_title(path.name, weight="bold")
        axis.axis("off")
        figure.tight_layout()
    plt.show()


def main() -> None:
    global NUM_UAVS, NUM_UES, SYSTEM_PRB_BUDGET, PRB_BUDGETS
    parser = argparse.ArgumentParser(description="Real MILP-validated 2-D C-SAEA/WE/CMA demonstration")
    parser.add_argument("--population", type=int, default=WE_DEFAULTS.population_size,
                        help="Initial WE cohort; default from GASettings.population_size.")
    parser.add_argument("--population-capacity", type=int,
                        default=WE_DEFAULTS.population_capacity,
                        help="Maximum simultaneous parents plus offspring; default from GASettings.population_capacity.")
    parser.add_argument("--generations", type=int, default=WE_DEFAULTS.generations,
                        help="WE generations; default from GASettings.generations.")
    parser.add_argument("--weight-method", choices=("legacy", "fixed", "contextual"), default="legacy",
                        help="Resource weights only: existing learner, fixed prior, or audited B*c learner.")
    parser.add_argument("--war-method", choices=("matching", "layered", "matching-multi", "matching-multi-reset"), default="layered",
                        help="Experimental family/matching WE, or previous layered WE (default).")
    parser.add_argument("--student-t", action="store_true",
                        help="Opt-in nominal Student-t resource screening; requires matching WE.")
    parser.add_argument("--joint-topk", action="store_true",
                        help="Run joint WE+CMA with primitive surrogate top-K MILP allocation.")
    parser.add_argument("--joint-milp-budget", type=int, default=4,
                        help="Maximum new fixed-placement MILP validations per joint generation.")
    parser.add_argument("--rank-samples", type=int, default=64,
                        help="Monte Carlo samples for provisional top-K probability.")
    parser.add_argument("--interval-confidence", type=float, default=0.95)
    parser.add_argument("--interval-min-samples", type=int, default=20,
                        help="Minimum distinct pre-evaluation errors before enabling intervals.")
    parser.add_argument("--interval-window", type=int, default=100)
    parser.add_argument("--interval-audit-period", type=int, default=5,
                        help="Random audit every N generations in Student-t or joint top-K mode.")
    parser.add_argument("--interval-strict-priorities", action="store_true",
                        help="Do not assume predicted V/C/S ties are true: unknown ties remain reserve.")
    parser.add_argument("--snapshot-period", type=int, default=10,
                        help="Draw one WE placement map every N generations (default: 10).")
    parser.add_argument("--compare-baseline", action="store_true",
                        help="Also run the no-WE GA baseline. Disabled by default.")
    parser.add_argument("--baseline-generations", type=int, default=34,
                        help="Longer baseline run to consume a comparable MILP budget.")
    parser.add_argument("--cma-iterations", type=int, default=3)
    parser.add_argument("--cma-population", type=int, default=8)
    parser.add_argument("--quick", action="store_true",
                        help="Run the same algorithm/settings with only 3 UAV and 15 UE.")
    parser.add_argument("--seed", type=int, default=config.seed)
    parser.add_argument("--ue-distribution", choices=("uniform", "hotspot"), default="uniform",
                        help="UE placement model; uniform is the default random spatial distribution.")
    parser.add_argument("--figure", type=Path, default=Path("hybrid_we_cma_2d_convergence.png"))
    parser.add_argument("--output", type=Path, default=Path("hybrid_we_cma_2d_convergence.json"))
    parser.set_defaults(show=True)
    parser.add_argument("--show", dest="show", action="store_true",
                        help="Show the two saved PNGs in Matplotlib windows (default).")
    parser.add_argument("--no-show", dest="show", action="store_false",
                        help="Save PNGs without showing Matplotlib windows.")
    parser.add_argument("--no-open", action="store_true",
                        help="Do not automatically open the final PNG after saving it.")
    args = parser.parse_args()
    if args.joint_topk and args.student_t:
        raise ValueError("--joint-topk replaces --student-t; use one mode")
    if args.cma_iterations < 1:
        raise ValueError("--cma-iterations must be at least 1")
    if args.snapshot_period <= 0:
        raise ValueError("--snapshot-period must be positive")
    if args.population_capacity < args.population + 1:
        raise ValueError("--population-capacity must exceed --population")
    screening_settings = None
    if args.student_t:
        from student_t_screening import ScreeningSettings
        if args.war_method != "matching":
            raise ValueError("Use --war-method matching with --student-t")
        screening_settings = ScreeningSettings(
            confidence=args.interval_confidence,
            min_samples=args.interval_min_samples,
            window=args.interval_window,
            audit_period=args.interval_audit_period,
            assume_predicted_priority_ties=not args.interval_strict_priorities,
        )

    NUM_UAVS, NUM_UES = config.num_uavs, config.num_ues
    if args.quick:
        # Only the scenario cardinalities change.  The GA, WE, CMA, radio,
        # MILP, number of interference updates, and all solver settings stay
        # exactly the same as the research configuration.
        NUM_UAVS = 3
        NUM_UES = 15
        print("Reduced scenario: 3 UAV, 15 UE; all algorithm settings unchanged.", flush=True)
    PRB_BUDGETS = (config.uav_max_prb,) * NUM_UAVS
    phys, scenario = configured_scenario(
        seed=args.seed, ue_distribution=args.ue_distribution, quick=args.quick)
    print(f"Config: {NUM_UAVS} UAV / {NUM_UES} UE; {config.length_m}x{config.width_m} m; "
          f"PRB system={SYSTEM_PRB_BUDGET}, per UAV={config.uav_max_prb}, per link<={phys.allocation_max_prbs}; "
          f"power UAV={phys.P_max_w:g} W, link<={phys.allocation_max_power_w:g} W, step={phys.power_step_w:g} W; "
          f"f={phys.f_c/1e9:g} GHz, NF={phys.F:g} dB; "
          f"h={min(phys.H_U):g}..{max(phys.H_U):g} m, theta={min(phys.Theta_U):g}..{max(phys.Theta_U):g} deg",
          flush=True)
    uavs, ues = scenario.uavs, scenario.ues
    evaluator, _cache = make_exact_evaluator(uavs, ues, phys)
    print("[1/3] Running C-SAEA + WE with exact MILP evaluations...", flush=True)

    baseline: dict[str, Any] | None = None
    if args.compare_baseline:
        # The baseline gets a longer horizon so it consumes a comparable number
        # of exact infill calls to WE plus the later CMA refinement.
        baseline_ga = build_ga(
            uavs=uavs, ues=ues, phys=phys, evaluator=evaluator, population=args.population,
            population_capacity=args.population_capacity,
            generations=args.baseline_generations, use_we=False, seed=args.seed,
            weight_method=args.weight_method,
        )
        baseline = baseline_ga.run()
    we_ga = build_ga(
        uavs=uavs, ues=ues, phys=phys, evaluator=evaluator, population=args.population,
        population_capacity=args.population_capacity,
        generations=args.generations, use_we=True, seed=args.seed,
        war_method=args.war_method,
        weight_method=args.weight_method,
        screening_settings=screening_settings,
        joint_topk=args.joint_topk,
        joint_milp_budget=args.joint_milp_budget,
        rank_samples=args.rank_samples,
        cma_pre_samples=args.cma_population,
        audit_period=args.interval_audit_period,
        min_residual_samples=args.interval_min_samples,
        nominal_confidence=args.interval_confidence,
    )
    print(
        f"WE settings: initial population={we_ga.settings.population_size}, "
        f"capacity={we_ga.settings.population_capacity}, "
        f"generations={we_ga.settings.generations}, "
        f"initial MILP seeds={we_ga.settings.initial_milp_seeds}, "
        f"update period={we_ga.settings.update_period}, "
        f"clusters={we_ga.settings.clusters}, "
        f"children/pair={we_ga.settings.children_per_pair}",
        flush=True,
    )
    we = we_ga.run()
    if args.joint_topk:
        final = we_ga.joint_exact[tuple(np.round(we["best_genome"], 7).ravel())].clone()
        cma_history = []
        print("[2/3] Joint CMA completed inside WE generations.", flush=True)
    else:
        print("[2/3] Running exact-CMA local refinement...", flush=True)
        final, cma_history = exact_cma_refinement(
            we_ga, we, iterations=args.cma_iterations, population=args.cma_population, seed=args.seed + 17,
        )
    print("[3/3] Saving 2-D convergence figures...", flush=True)

    draw_figure(
        ues=ues, phys=phys, evaluator=evaluator,
        we_history=we["exact_incumbent_history"],
        baseline_history=None if baseline is None else baseline["exact_incumbent_history"],
        cma_history=cma_history,
        output=args.figure, show=False, joint_topk=args.joint_topk,
    )
    all_steps_figure = args.figure.with_name(f"{args.figure.stem}_all_steps.png")
    draw_all_steps_figure(
        ues=ues, phys=phys, evaluator=evaluator,
        we_history=we["exact_incumbent_history"], cma_history=cma_history,
        output=all_steps_figure, snapshot_period=args.snapshot_period,
        joint_topk=args.joint_topk,
    )
    service_resource_figure = args.figure.with_name(
        f"{args.figure.stem}_we_service_resources.png")
    draw_we_service_resource_figure(
        we["exact_incumbent_history"], service_resource_figure)
    final_exact = final.exact_result
    summary = {
        "assumptions": {
            "uavs": NUM_UAVS, "ues": NUM_UES, "system_max_prbs": SYSTEM_PRB_BUDGET,
            "area_m": [AREA_LENGTH_M, AREA_WIDTH_M],
            "ue_distribution": args.ue_distribution,
            "continuous_height_bounds_m": [min(phys.H_U), max(phys.H_U)],
            "continuous_theta_bounds_deg": [min(phys.Theta_U), max(phys.Theta_U)],
            "generations": args.generations,
            "active_population": args.population,
            "population_capacity": args.population_capacity,
            "initial_milp_seeds": we_ga.settings.initial_milp_seeds,
            "update_period": we_ga.settings.update_period,
            "clusters": we_ga.settings.clusters,
            "per_uav_prb_budgets": list(PRB_BUDGETS), "prb_bandwidth_hz": PRB_BANDWIDTH_HZ,
            "uav_max_power_w": UAV_POWER_BUDGET_W, "ue_demands_mbps": list(UE_DEMANDS_MBPS),
            "seed": args.seed,
            "initialization": (
                "all UAVs and all initial individuals share the area-centre x/y; "
                "h and theta are sampled uniformly from their configured bounds"
            ),
            "parameter_source": "config.py",
            "carrier_hz": phys.f_c, "noise_figure_db": phys.F,
            "power_step_w": phys.power_step_w,
            "power_levels_w": list(phys.power_levels_w),
            "allocation_max_prbs": phys.allocation_max_prbs,
            "allocation_max_power_w": phys.allocation_max_power_w,
            "grid_intervals_per_axis": config.grid_size,
            "orthogonal_prb_pool": config.global_orthogonal_prb_pool,
            "solver_mip_gap": config.exact_mip_gap,
            "solver_num_threads": config.num_threads,
            "war_method": "joint-topk" if args.joint_topk else args.war_method,
            "weight_method": args.weight_method,
            "note_we_enabled": bool(args.student_t or args.joint_topk),
            "joint_topk_enabled": bool(args.joint_topk),
            "sbx_uav_blocks": we_ga.settings.sbx_uav_blocks,
            "children_per_pair": we_ga.settings.children_per_pair,
        },
        "csaea_we_before_cma": we["exact_incumbent_history"][-1],
        "hybrid_we_exact_cma": (we["exact_incumbent_history"][-1]
                                if args.joint_topk else cma_history[-1]),
        "we_incumbent_history": we["exact_incumbent_history"],
        "we_population_history": we["history"],
        "war_history": we["war_history"],
        "exact_trace": we_ga.exact_trace,
        "unique_milp_solves": evaluator.unique_solves,
        "milp_solve_seconds": evaluator.solve_seconds,
        "weight_learning_history": we_ga.weight_learning_history,
        "learned_vartheta": we_ga.vartheta.tolist(),
        "cma_history": cma_history,
        "final_milp": final_exact,
        "all_steps_figure": str(all_steps_figure),
        "we_service_resource_figure": str(service_resource_figure),
        "note": (
            "Every reported incumbent was evaluated by the fixed-placement HiGHS MILP "
            f"with one globally orthogonal {SYSTEM_PRB_BUDGET}-PRB pool and local "
            f"{UAV_POWER_BUDGET_W:.1f}-W UAV power limits."
        ),
    }
    if baseline is not None:
        summary["ga_baseline"] = baseline["exact_incumbent_history"][-1]
    screening_figure = None
    surrogate_quality_figure = None
    if args.joint_topk:
        summary["joint_topk"] = {
            "milp_budget_per_generation": args.joint_milp_budget,
            "rank_samples": args.rank_samples,
            "cma_pre_samples": args.cma_population,
            "audit_period": args.interval_audit_period,
            "history": we["joint_topk_history"],
            "checks": we["joint_topk_checks"],
            "cma_updates": we["joint_cma_updates"],
            "cost": "J = beta*pbar + mu*nbar + eta*max_u(power_load_u, prb_load_u)",
            "audit_interpretation": (
                "A rescue compares exact audit quality with the frozen provisional "
                "top-K cut; it is not a population-wide false-drop probability."
            ),
        }
        from joint_topk_plots import draw_surrogate_screening_quality
        surrogate_quality_figure = args.figure.with_name(
            f"{args.figure.stem}_surrogate_screening_quality.png")
        draw_surrogate_screening_quality(
            checks=we["joint_topk_checks"],
            generations=[row["generation"] for row in we["exact_incumbent_history"]],
            output=surrogate_quality_figure,
            rolling_checks=20,
            nominal_confidence=args.interval_confidence,
            audit_label="Audited outside-topK rescue vs provisional cut",
        )
        summary["joint_topk"]["quality_figure"] = str(surrogate_quality_figure)
    if args.student_t:
        summary["student_t"] = {
            "settings": we["student_t_settings"],
            "history": we_ga.screening_history,
            "checks": we_ga.screening_checks,
            "residual_records": [
                {"error_resource": error.tolist(), "predictor_version": version,
                 "generation": generation}
                for error, version, generation in we_ga.residual_archive.records
            ],
            "cost": "J = beta*pbar + mu*nbar + eta*z; no idle-UAV penalty in this opt-in mode",
            "z_definition": "existing bottleneck pressure: max(0, max(peak power load, global PRB load) - target)",
            "incumbent_resource_weights": we_ga.vartheta_prior[:, 0].tolist(),
            "limitations": [
                "Intervals have nominal coverage under iid-normal errors, not certified online WE accuracy.",
                "Rolling residuals span predictor versions and may depend on weight training data.",
                "Predicted priority ties are assumptions unless strict-priorities is enabled.",
                "The provisional survivor boundary may be predicted; both resource intervals are propagated.",
                "Unknown or unequal V/C/S priorities cannot be certified by a resource-cost interval.",
                "Capacity/budget removals of reserve candidates are heuristic, not confidence-certified.",
                "Audit of drops does not estimate P(drop | genuinely good) for the whole population.",
                "Periodic infill and exact-CMA retain their original evaluation budgets.",
            ],
        }
        from student_t_we import draw_screening_history, draw_surrogate_screening_quality
        screening_figure = args.figure.with_name(f"{args.figure.stem}_groups.png")
        draw_screening_history(we_ga.screening_history, screening_figure)
        summary["student_t"]["groups_figure"] = str(screening_figure)
        surrogate_quality_figure = args.figure.with_name(
            f"{args.figure.stem}_surrogate_screening_quality.png")
        draw_surrogate_screening_quality(
            checks=we_ga.screening_checks,
            generations=[row["generation"] for row in we["exact_incumbent_history"]],
            output=surrogate_quality_figure,
            rolling_checks=20,
            nominal_confidence=args.interval_confidence,
        )
        summary["student_t"]["quality_figure"] = str(surrogate_quality_figure)
    args.output.write_text(json.dumps(summary, indent=2), encoding="utf-8")
    print(json.dumps({
        "assumptions": summary["assumptions"],
        f"we_generation_{args.generations}": {
            key: summary["csaea_we_before_cma"][key]
            for key in ("served_ues", "prbs", "power_w", "exact_evaluations")
        },
        "final_joint" if args.joint_topk else "final_cma": {
            key: summary["hybrid_we_exact_cma"][key]
            for key in ("served_ues", "prbs", "power_w", "exact_evaluations")
        },
    }, indent=2))
    print(f"2-D convergence figure: {args.figure}")
    print(f"Every-generation 2-D timeline: {all_steps_figure}")
    print(f"WE service/resources: {service_resource_figure}")
    if screening_figure is not None:
        print(f"Student-t groups: {screening_figure}")
    if surrogate_quality_figure is not None:
        print(f"Surrogate/screening quality: {surrogate_quality_figure}")
    if args.show:
        requested_figures = ((args.figure, service_resource_figure)
                             if args.joint_topk else (service_resource_figure,))
        if surrogate_quality_figure is not None:
            requested_figures = (*requested_figures, surrogate_quality_figure)
        show_saved_figures(requested_figures)
    if not args.no_open and os.name == "nt":
        # VS Code's "Run Python File" uses a terminal; display the placement
        # figure as well when the new joint mode is selected.
        if args.joint_topk:
            os.startfile(args.figure.resolve())
        os.startfile(service_resource_figure.resolve())
        if surrogate_quality_figure is not None:
            os.startfile(surrogate_quality_figure.resolve())


if __name__ == "__main__":
    main()
