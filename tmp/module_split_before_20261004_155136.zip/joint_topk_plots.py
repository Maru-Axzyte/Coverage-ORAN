"""Pre-evaluation surrogate diagnostics for the joint WE/CMA runner."""
from pathlib import Path
import numpy as np
import matplotlib.pyplot as plt


def rolling_quality(checks, generations, rolling_checks=20):
    if rolling_checks < 1:
        raise ValueError("rolling_checks must be positive")
    rows = []
    for generation in generations:
        recent = [r for r in checks if r["generation"] <= generation][-rolling_checks:]
        covered = [r["interval_covered"] for r in recent if r.get("interval_covered") is not None]
        audited = [r["outside_topk_rescue"] for r in recent if r.get("outside_topk_rescue") is not None]
        rows.append({"generation": generation,
            "mae": float(np.mean([abs(r["error_j"]) for r in recent])) if recent else np.nan,
            "coverage": float(np.mean(covered)) if covered else np.nan,
            "rescue": float(np.mean(audited)) if audited else np.nan,
            "checks": len(recent), "interval_checks": len(covered), "audit_checks": len(audited)})
    return rows


def draw_surrogate_screening_quality(*, checks, generations, output,
                                     rolling_checks=20, nominal_confidence=.95,
                                     audit_label="Audited outside-topK rescue vs provisional cut"):
    rows = rolling_quality(checks, generations, rolling_checks)
    g = [r["generation"] for r in rows]
    fig, axes = plt.subplots(2, 1, figsize=(11, 7), sharex=True)
    axes[0].plot(g, [r["mae"] for r in rows], color="#4c72b0", linewidth=2,
                 label=r"Rolling MAE: $|J_{MILP}-\widehat J|$")
    axes[0].set_ylabel("Absolute resource-cost error")
    axes[0].set_title(f"Surrogate and screening quality (last {rolling_checks} MILP-audited predictions)",
                      weight="bold")
    axes[1].plot(g, [r["coverage"] for r in rows], color="#187a48", linewidth=2,
                 label="Observed interval coverage (calibrated checks only)")
    axes[1].plot(g, [r["rescue"] for r in rows], color="#c44e52", linewidth=2, label=audit_label)
    axes[1].axhline(nominal_confidence, color="#187a48", linestyle=":",
                    label=f"Nominal confidence ({nominal_confidence:.0%})")
    axes[1].set_ylim(-.04, 1.04)
    axes[1].set_ylabel("Observed fraction")
    axes[1].set_xlabel("WE generation")
    for ax in axes:
        ax.grid(alpha=.25)
        ax.legend(loc="best", fontsize=9)
    fig.text(.02, .015, "Missing evidence is shown as a gap, not zero. Intervals are nominal; "
             "audit rescues compare against the provisional cut.", fontsize=8)
    fig.tight_layout(rect=(0, .035, 1, 1))
    output = Path(output)
    output.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(output, dpi=180, bbox_inches="tight")
    plt.close(fig)
