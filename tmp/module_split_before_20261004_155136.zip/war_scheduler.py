"""Family/global WE with exact one-dimensional minimum-gap matchings.

An individual is a complete placement, NOT another physical UAV. Scores are
Swiss-style points; the existing WE ordering breaks equal-score ties. This is
not an implementation of all FIDE rules (no colours or no-rematch constraint).
"""
from __future__ import annotations

import math
from typing import Any, Callable, Hashable, Sequence


def minimum_gap_pairs(scores: Sequence[float], bye_counts: Sequence[int] | None = None):
    """Solve min sum g_ij |s_i-s_j|, degree_i+b_i=1, sum b_i=N mod 2.

    For even N an optimal matching pairs adjacent sorted values: uncrossing
    cannot increase absolute-distance cost. For odd N, test each possible bye
    using prefix/suffix pair costs and one bridge pair for even-indexed byes.
    Thus
    this solves the binary model exactly in O(N log N), without an IP solver.
    Among optimal byes prefer fewer previous byes, then input order.
    """
    n = len(scores)
    if any(not math.isfinite(float(s)) for s in scores):
        raise ValueError("Matching scores must be finite")
    counts = [0] * n if bye_counts is None else list(bye_counts)
    if len(counts) != n:
        raise ValueError("One bye count per participant is required")
    order = sorted(range(n), key=lambda i: scores[i])
    bye = None
    if n % 2:
        prefix = [0.0] * (n + 1)
        suffix = [0.0] * (n + 1)
        for k in range(2, n + 1, 2):
            prefix[k] = prefix[k - 2] + scores[order[k - 1]] - scores[order[k - 2]]
        for k in range(n - 2, -1, -2):
            suffix[k] = suffix[k + 2] + scores[order[k + 1]] - scores[order[k]]
        # Testing all positions also permits fairer byes when values tie.
        options = []
        for k in range(n):
            if k % 2 == 0:
                cost = prefix[k] + suffix[k + 1]
            else:
                cost = prefix[k - 1] + scores[order[k + 1]] - scores[order[k - 1]] + suffix[k + 2]
            options.append((cost, counts[order[k]], k))
        _, _, pos = min(options)
        bye = order.pop(pos)
    pairs = [(order[k], order[k + 1]) for k in range(0, len(order), 2)]
    return pairs, bye


def war_survival(
    pool: Sequence[Any], target: int, incumbent: Any, *,
    key: Callable[[Any], Hashable], ordered: Callable, better: Callable,
    better_exact: Callable, evaluate_exact: Callable, families: Sequence[Sequence[Hashable]] = (),
    verification_budget: int = 0,
    staged: bool = False, carry_scores: bool = True,
) -> tuple[list[Any], dict]:
    """One gentle family round, then global weak-loser elimination.

    Exact incumbent is protected. A loss nominates an individual for deletion;
    only the worst losers are deleted, never all losers blindly. One shared
    verification budget checks uncertain candidates near the proposed cut,
    BEFORE committing results. No new surrogate or fitness is introduced.
    """
    if target < 2 or verification_budget < 0:
        raise ValueError("target >= 2 and verification_budget >= 0 required")
    unique = {}
    for item in [*pool, incumbent]:
        ident = key(item)
        if ident not in unique or item.exact_result is not None:
            unique[ident] = item
    active = ordered(list(unique.values()))
    target = min(target, len(active))
    elite = unique[key(incumbent)]
    points = {k: 0.0 for k in unique}
    byes = {k: 0 for k in unique}
    report = {"initial": len(active), "target": target, "verified": 0,
              "rounds": [], "fallback": False, "staged": staged,
              "carry_scores": carry_scores}

    def refresh_elite():
        nonlocal elite
        for item in active:
            if item.exact_result is not None and better_exact(item, elite):
                elite = item

    def round_once(groups, phase, fraction, removal_limit=None):
        nonlocal active
        matches, resting, zero_matches, zero_resting = [], [], [], []
        score_levels = set()
        for group in groups:
            group = ordered(group)  # strength tie-break within equal points
            score_levels.update(points[key(x)] for x in group)
            pairs, bye = minimum_gap_pairs([points[key(x)] for x in group],
                                           [byes[key(x)] for x in group])
            matches.extend((group[i], group[j]) for i, j in pairs)
            if bye is not None:
                resting.append(group[bye])
            zero_pairs, zero_bye = minimum_gap_pairs([0.0] * len(group),
                                                     [byes[key(x)] for x in group])
            zero_matches.extend((group[i], group[j]) for i, j in zero_pairs)
            if zero_bye is not None:
                zero_resting.append(group[zero_bye])

        def outcomes(schedule=matches):
            losers, winners, draws = [], [], []
            for a, b in schedule:
                if better(a, b):
                    winners.append(a); losers.append(b)
                elif better(b, a):
                    winners.append(b); losers.append(a)
                else:
                    # Stable final tie-break only; draw still gives half points.
                    draws.extend((a, b)); losers.append(b)
            eligible = ordered([x for x in losers if key(x) != key(elite)])
            count = min(max(0, len(active) - target), math.ceil(fraction * len(eligible)))
            if removal_limit is not None:
                count = min(count, removal_limit)
            removed = eligible[-count:] if count else []
            return removed, winners, draws

        refresh_elite()
        removed, _, _ = outcomes()
        proposed_keys = {key(x) for x in removed}
        checked_keys = set()
        remaining_budget = verification_budget - report["verified"]
        if remaining_budget:
            removed_keys = {key(x) for x in removed}
            retained = ordered([x for x in active if key(x) not in removed_keys])
            # Both sides of the cut; if not contracting yet, verify a promising
            # unknown instead. Uncertainty is heuristic, not a probability.
            boundary = (ordered(removed)[:2 * remaining_budget] + retained[-2 * remaining_budget:]
                        if removed else retained[:2 * remaining_budget])
            unknown = [x for x in boundary if x.exact_result is None]
            if not unknown:
                unknown = [x for x in retained if x.exact_result is None][:2 * remaining_budget]
            unknown.sort(key=lambda x: -x.uncertainty)
            for item in unknown[:remaining_budget]:
                evaluate_exact(item)
                report["verified"] += 1
                checked_keys.add(key(item))
            refresh_elite()
        # Predictions replaced by real evaluations before scoring/deletion.
        removed, winners, draws = outcomes()
        # Frozen-label counterfactual: same active cohort, byes, comparator and
        # exact labels, but zero all scheduling scores. Not another MILP call.
        zero_removed, _, _ = outcomes(zero_matches)
        removed_keys = {key(x) for x in removed}
        pair_keys = {frozenset((key(a), key(b))) for a, b in matches}
        zero_pair_keys = {frozenset((key(a), key(b))) for a, b in zero_matches}
        cost = sum(abs(points[key(a)] - points[key(b)]) for a, b in matches)
        for item in winners:
            points[key(item)] += 1.0
        for item in draws:
            points[key(item)] += 0.5
        for item in resting:
            byes[key(item)] += 1  # rest is NOT a win
        report["rounds"].append({"phase": phase, "participants": len(active),
                                 "matches": len(matches), "byes": len(resting),
                                 "eliminated": len(removed),
                                 "distinct_scores": len(score_levels), "pairing_cost": cost,
                                 "pairs_changed_vs_zero": len(pair_keys - zero_pair_keys),
                                 "byes_changed_vs_zero": len({key(x) for x in resting}
                                                            ^ {key(x) for x in zero_resting}),
                                 "removed_changed_vs_zero": len(removed_keys
                                                               ^ {key(x) for x in zero_removed}),
                                 "verified": len(checked_keys),
                                 "verified_rescued": len(checked_keys & (proposed_keys - removed_keys)),
                                 "removal_changes_after_verification": len(proposed_keys ^ removed_keys)})
        active = [x for x in active if key(x) not in removed_keys]

    if families:
        # A shared parent fights only once per round. Children are never removed
        # by a per-family quota; every unique child enters a group.
        unused = {key(x): x for x in active}
        groups = []
        for family in families:
            group = []
            for ident in family:
                if ident in unused:
                    group.append(unused.pop(ident))
            if group:
                groups.append(group)
        if unused:
            groups.append(list(unused.values()))
        # Reserve deletions for global opposition instead of exhausting the
        # whole survivor deficit locally. No new tunable penalty/weight.
        local_limit = max(0, len(active) - target) // 3 if staged else None
        round_once(groups, "family", 0.5, local_limit)
        points = {k: 0.0 for k in unique}  # local-family points are not comparable

    iterations = 0
    while len(active) > target or (not report["rounds"] and active):
        if not carry_scores:
            points = {k: 0.0 for k in unique}
        # If there is anything to delete, reserve at least one deletion for a
        # second global round. Even deficit=1 gets a warm-up then a real cut.
        limit = max(0, len(active) - target) // 2 if staged and iterations == 0 else None
        round_once([active], "global", 1.0, limit)
        iterations += 1
        if iterations > 2 * len(unique):
            # Defensive termination under an inconsistent user comparator.
            report["fallback"] = True
            active = [elite] + [x for x in ordered(active) if key(x) != key(elite)][:target - 1]
            break
    report["survivors"] = len(active)
    return ordered(active), report
