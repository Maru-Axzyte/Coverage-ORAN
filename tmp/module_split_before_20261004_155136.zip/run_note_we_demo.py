"""Run Python File in VS Code: note-aligned WE, unchanged radio/MILP scenario.

No simulation runs on import. Uses separate output names to preserve old plots.
"""
import sys
from pathlib import Path


if __name__ == "__main__":
    from run_hybrid_we_cma_demo import main

    output_dir = Path(__file__).resolve().parent
    sys.argv[1:1] = [
        "--weight-method", "contextual", "--joint-topk",
        "--figure", str(output_dir / "note_we_2d_convergence.png"),
        "--output", str(output_dir / "note_we_2d_convergence.json"), "--show",
    ]
    main()
